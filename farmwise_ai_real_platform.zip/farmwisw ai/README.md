# FarmWise AI

India-realistic crop-to-market decision intelligence for farmers.

FarmWise connects farm conditions to crop recommendations, sowing windows, market net realization, buyer matching, enquiries, weather, and impact estimates — all served live from the FastAPI backend. There is no offline/demo mode: every screen reads and writes real data through the API.

## Live frontend

After GitHub Pages finishes its first deployment, the frontend is available at:

`https://tharun-rk.github.io/FARMWISE-AI/`

The repository URL is the source-code page, not the running application. The frontend requires `VITE_API_URL` to point at a running backend (see below) — without it, nothing will load beyond the login screen.

## Local development

```powershell
npm install
npm run dev
```

Frontend: `http://127.0.0.1:5173/`

Backend:

```powershell
cd backend
python -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe scripts\seed_database.py
.venv\Scripts\python.exe -m uvicorn app.main:app --reload --port 8000
```

Swagger: `http://127.0.0.1:8000/docs`

By default the frontend talks to `http://127.0.0.1:8000/api/v1`. To point it elsewhere, create a `.env` file (see `.env.example` conventions in most Vite projects) with:

```
VITE_API_URL=http://127.0.0.1:8000/api/v1
```

## Seeded account

Running `scripts/seed_database.py` creates one starter farmer account plus a full catalog of 10 crops, 10 markets (with price history for every crop), and 30 buyers (each interested in a few different crops), so every screen has real data to work with immediately:

```text
Phone: +919999999999
Password: DemoPass123!
```

Sign up for your own account (as a farmer or a buyer/broker) to build a profile from scratch.

## Deployment

The frontend deploys through `.github/workflows/deploy-pages.yml`, which runs `npm run build` and publishes `dist/`. Set the GitHub repository variable `VITE_API_URL` to your deployed backend's API URL (see below) before running the workflow, or the deployed frontend will not be able to reach any backend.

### Deploy the backend on Render

1. Create a new Render Blueprint from this repository.
2. Select `backend/render.yaml`.
3. Wait for the web service and PostgreSQL database to become healthy.
4. Run `python scripts/seed_database.py` once against the deployed database (e.g. via the Render shell) so crops, markets, and buyers exist.
5. Copy the API URL, for example `https://farmwise-ai-api.onrender.com`.
6. Set the GitHub repository variable `VITE_API_URL` to `https://farmwise-ai-api.onrender.com/api/v1`.
7. Run the Pages workflow again.

All market, buyer, weather, and financial values are computed estimates from real inputs — not guarantees, and clearly labeled as such throughout the app.
