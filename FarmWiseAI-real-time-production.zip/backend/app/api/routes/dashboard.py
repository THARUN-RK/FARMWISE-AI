"""
Dashboard and analytics routes.

The impact endpoint calculates real statistics from the authenticated
farmer's farm and harvest data rather than hardcoded demo values.
"""
import logging

from fastapi import APIRouter, Depends
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.api.deps import current_user, farmer_only
from app.core.database import get_db
from app.models.entities import Buyer, Enquiry, Farm, Farmer, Harvest, Recommendation
from app.schemas.common import ProfitRequest
from app.services.engines import calculate_profit

log = logging.getLogger("farmwise.dashboard")
router = APIRouter(tags=["dashboard"])


def _response(data, message: str = ""):
    return {"success": True, "data": data, "message": message}


@router.get("/alerts")
async def alerts(user=Depends(current_user)):
    """Build alerts from the user's current weather instead of fixed demo messages."""
    if user.latitude is None or user.longitude is None:
        return _response([{"type":"profile","severity":"low","message":"Add your farm location to activate weather-based alerts."}])
    from app.api.routes.weather import _fetch
    try:
        weather = await _fetch(user.latitude, user.longitude)
    except Exception:
        return _response([])
    alerts=[]
    forecast=weather.get("forecast", [])
    max_rain=max((d.get("rain_probability_percent",0) or 0 for d in forecast[:3]), default=0)
    max_mm=max((d.get("precipitation_mm",0) or 0 for d in forecast[:3]), default=0)
    if max_rain >= 70 or max_mm >= 20:
        alerts.append({"type":"weather","severity":"high","message":f"Rain risk is elevated over the next 3 days (up to {round(max_rain)}% probability). Review irrigation and field access plans."})
    elif max_rain >= 40:
        alerts.append({"type":"weather","severity":"medium","message":f"Moderate rain risk is expected over the next 3 days (up to {round(max_rain)}%)."})
    current=weather.get("current",{})
    if (current.get("wind_speed_kmh") or 0) >= 35:
        alerts.append({"type":"weather","severity":"high","message":f"Current wind is {round(current['wind_speed_kmh'])} km/h. Avoid spraying during strong winds."})
    return _response(alerts)


@router.get("/dashboard/impact")
def impact(user=Depends(farmer_only), db: Session = Depends(get_db)):
    """
    Return farm impact estimates based on real farm data.

    Values are estimates based on the farmer's farm profile and
    historical crop data — not financial guarantees.
    """
    farm = db.scalar(select(Farm).where(Farm.farmer_id == user.id))
    acres = farm.land_size_acres if farm else 1.0

    # Count real harvests for this farmer
    harvest_count = db.scalar(select(func.count(Harvest.id)).where(Harvest.farmer_id == user.id)) or 0
    enquiry_count = db.scalar(select(func.count(Enquiry.id)).where(Enquiry.farmer_id == user.id)) or 0
    completed_enquiries = db.scalar(
        select(func.count(Enquiry.id)).where(
            Enquiry.farmer_id == user.id,
            Enquiry.status.in_(["accepted", "completed"]),
        )
    ) or 0

    # Get latest recommendation score if available
    latest_rec = db.scalar(
        select(Recommendation)
        .where(Recommendation.farmer_id == user.id, Recommendation.recommendation_type == "crop")
        .order_by(Recommendation.created_at.desc())
    )

    return _response(
        {
            "farm_acres": acres,
            "expected_net_realization": None,
            "expected_farmer_profit": None,
            "transport_cost_per_kg": None,
            "estimated_selling_delay_days": None,
            "post_harvest_loss_assumption_percent": None,
            "water_efficiency_index": None,
            "input_efficiency_index": None,
            "harvest_count": harvest_count,
            "enquiry_count": enquiry_count,
            "completed_deals": completed_enquiries,
            "top_crop_score": latest_rec.score if latest_rec else None,
            "data_label": "Account metrics only — financial estimates require a recorded harvest and live market quote",
        }
    )


@router.post("/profit/calculate")
def profit_calculate(body: ProfitRequest):
    """Calculate estimated profit from supplied inputs."""
    return _response(calculate_profit(body.model_dump()), "Profit calculated from supplied estimates")


@router.get("/admin/analytics")
def admin_analytics(user=Depends(current_user), db: Session = Depends(get_db)):
    """Admin-only: platform-wide statistics."""
    if user.role != "admin":
        from fastapi import HTTPException
        raise HTTPException(403, "Admin access required")
    return _response(
        {
            "registered_farmers": db.scalar(select(func.count(Farmer.id))) or 0,
            "active_farms": db.scalar(select(func.count(Farm.id))) or 0,
            "harvests": db.scalar(select(func.count(Harvest.id))) or 0,
            "enquiries": db.scalar(select(func.count(Enquiry.id))) or 0,
            "successful_matches": db.scalar(
                select(func.count(Enquiry.id)).where(Enquiry.status.in_(["accepted", "completed"]))
            ) or 0,
        }
    )
