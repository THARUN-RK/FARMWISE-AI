from datetime import date, timedelta
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from sqlalchemy import select
from app.core.database import Base, SessionLocal, engine
from app.core.security import hash_password
from app.models.entities import Buyer, BuyerRequirement, Crop, Farm, Farmer, Market, MarketPrice

CROPS = [("Groundnut", "Arachis hypogaea", 110, "Low", 17000, 950, "Low"), ("Chilli", "Capsicum annuum", 120, "Medium", 24000, 700, "Medium"), ("Tomato", "Solanum lycopersicum", 95, "Medium", 30000, 2800, "Low"), ("Onion", "Allium cepa", 110, "Medium", 26000, 2500, "Medium"), ("Maize", "Zea mays", 100, "Medium", 18000, 2200, "Low"), ("Paddy", "Oryza sativa", 125, "High", 28000, 2600, "Medium"), ("Cotton", "Gossypium", 170, "Medium", 32000, 700, "Medium"), ("Potato", "Solanum tuberosum", 100, "Medium", 35000, 5000, "Medium"), ("Turmeric", "Curcuma longa", 210, "High", 45000, 2800, "Medium"), ("Sugarcane", "Saccharum officinarum", 300, "High", 65000, 32000, "Low")]
MARKET_NAMES = ["Market A", "Market B", "Market C", "Guntur Central", "Mangalagiri APMC", "Vijayawada Wholesale", "Kurnool Yard", "Anantapur Market", "Mysuru APMC", "Hubballi Market"]

def seed():
    """Seed only non-user agricultural reference crops.

    Production deployments must not create demo users or synthetic market/buyer
    records. Market and buyer data should come from a verified data source or
    be entered by an administrator.
    """
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        existing = {name for name in db.scalars(select(Crop.name)).all()}
        added = 0
        for name, scientific, duration, water, cost, yield_, risk in CROPS:
            if name in existing:
                continue
            db.add(
                Crop(
                    name=name,
                    scientific_name=scientific,
                    duration_days=duration,
                    water_requirement=water,
                    soil_types="Loamy,Red loam,Black soil",
                    suitable_seasons="Kharif,Rabi",
                    climate_requirement="18-35C",
                    base_production_cost_per_acre=cost,
                    expected_yield_per_acre=yield_,
                    risk_level=risk,
                    description=f"Agricultural reference profile for {name}.",
                )
            )
            added += 1
        db.commit()
        print(f"Seeded {added} crop reference records; no demo users, buyers, markets, or prices created.")
    finally:
        db.close()


if __name__ == "__main__":
    seed()
