"""Market discovery with optional live AGMARKNET/data.gov.in integration."""
import logging, time
from datetime import date, timedelta
from typing import Any
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.api.deps import current_user, farmer_only
from app.core.config import settings
from app.core.database import get_db
from app.core.http_client import get_http_client
from app.models.entities import Crop, Harvest, Market, MarketPrice
from app.schemas.common import MarketRequest
from app.services.engines import MarketRankingService
from app.utils.distance import calculate_distance_km

log = logging.getLogger("farmwise.markets")
router = APIRouter(prefix="/markets", tags=["markets"])
_cache: dict[str, tuple[float, Any]] = {}

def _response(data, message=""): return {"success": True, "data": data, "message": message}

def _crop_alias(crop: str) -> str:
    aliases = {"groundnut":"Groundnut", "peanut":"Groundnut", "chilli":"Chilli", "chili":"Chilli", "tomato":"Tomato"}
    return aliases.get(crop.lower(), crop)

async def _live_prices(commodity: str) -> dict:
    if not settings.market_data_api_key:
        raise HTTPException(503, "Live mandi prices are not configured. Add MARKET_DATA_API_KEY on the backend.")
    key = _crop_alias(commodity).lower(); cached = _cache.get(key)
    if cached and time.time() - cached[0] < settings.market_cache_seconds: return cached[1]
    client = await get_http_client()
    params = {"api-key": settings.market_data_api_key, "format":"json", "limit":1000, "filters[commodity]": _crop_alias(commodity)}
    try:
        r = await client.get(settings.market_data_url, params=params); r.raise_for_status(); raw = r.json()
    except Exception as exc:
        log.warning("market provider failure: %s", exc)
        raise HTTPException(503, "Live market service is temporarily unavailable.") from exc
    rows=[]
    for x in raw.get("records", []):
        try:
            rows.append({
                "state": x.get("state"), "district": x.get("district"), "market": x.get("market"),
                "commodity": x.get("commodity"), "variety": x.get("variety"),
                "arrival_date": x.get("arrival_date"),
                "min_price": float(str(x.get("min_price", 0)).replace(",","")),
                "max_price": float(str(x.get("max_price", 0)).replace(",","")),
                "modal_price": float(str(x.get("modal_price", 0)).replace(",","")),
            })
        except (TypeError, ValueError): continue
    result={"provider":"data.gov.in/AGMARKNET", "fetched_at":time.time(), "commodity":_crop_alias(commodity), "records":rows}
    _cache[key]=(time.time(),result); return result

@router.get("")
def list_markets(db: Session = Depends(get_db)):
    markets = db.scalars(select(Market).where(Market.active.is_(True))).all()
    return _response([{"id":m.id,"name":m.name,"location_name":m.location_name,"active":m.active} for m in markets])

@router.get("/live")
async def live_market_prices(commodity: str = Query("Groundnut", min_length=2, max_length=80), state: str | None = Query(None, max_length=80), district: str | None = Query(None, max_length=80), user=Depends(current_user)):
    data=await _live_prices(commodity)
    rows=data["records"]
    if state: rows=[r for r in rows if (r.get("state") or "").lower()==state.lower()]
    if district: rows=[r for r in rows if (r.get("district") or "").lower()==district.lower()]
    return _response({**data,"records":rows}, "Live market prices fetched")

@router.get("/live/ranked")
async def live_ranked_markets(
    commodity: str = Query("Groundnut", min_length=2, max_length=80),
    user=Depends(current_user),
    db: Session = Depends(get_db),
):
    """Combine live mandi modal prices with FarmWise market geography/cost data."""
    if user.latitude is None or user.longitude is None:
        raise HTTPException(422, "Add your farm location in Profile before comparing live markets.")
    data = await _live_prices(commodity)
    rows = data["records"]
    markets = db.scalars(select(Market).where(Market.active.is_(True))).all()
    output = []
    for market in markets:
        candidates = [r for r in rows if (r.get("market") or "").strip().lower() == market.name.strip().lower()]
        if not candidates:
            candidates = [r for r in rows if market.name.split()[0].lower() in (r.get("market") or "").lower()]
        if not candidates:
            continue
        quote = max(candidates, key=lambda r: r.get("modal_price", 0) or 0)
        distance = calculate_distance_km(user.latitude, user.longitude, market.latitude, market.longitude)
        transport = round(market.transport_base_cost + distance * 0.015, 2)
        charges = market.market_charge_per_kg
        modal = quote["modal_price"]
        output.append({
            "market_id": market.id, "market": market.name, "location_name": market.location_name,
            "price_per_kg": modal, "distance_km": round(distance, 1),
            "transport_cost_per_kg": transport, "market_charges_per_kg": charges,
            "net_realization_per_kg": round(modal - transport - charges, 2),
            "demand": "live mandi quote", "arrival_date": quote.get("arrival_date"),
            "min_price": quote.get("min_price"), "max_price": quote.get("max_price"),
            "provider": data["provider"], "fetched_at": data["fetched_at"],
        })
    # If the local market reference table has no matching market yet, still expose
    # the verified live mandi quotes rather than fabricating transport/geography.
    if not output:
        for r in sorted(rows, key=lambda x: x.get("modal_price", 0) or 0, reverse=True)[:50]:
            output.append({
                "market_id": None, "market": r.get("market") or "Unknown mandi",
                "location_name": ", ".join(filter(None, [r.get("district"), r.get("state")])),
                "price_per_kg": r.get("modal_price"), "distance_km": None,
                "transport_cost_per_kg": None, "market_charges_per_kg": None,
                "net_realization_per_kg": None, "demand": "live mandi quote",
                "arrival_date": r.get("arrival_date"), "min_price": r.get("min_price"),
                "max_price": r.get("max_price"), "provider": data["provider"],
                "fetched_at": data["fetched_at"],
            })
    output.sort(key=lambda x: x["price_per_kg"] or 0, reverse=True)
    for i,row in enumerate(output): row["recommended"] = i == 0
    return _response({"commodity": data["commodity"], "markets": output, "provider": data["provider"], "fetched_at": data["fetched_at"]}, "Live mandi prices fetched")

@router.get("/prices")
def market_prices(crop_id:int|None=None, market_id:int|None=None, db:Session=Depends(get_db)):
    q=select(MarketPrice)
    if crop_id: q=q.where(MarketPrice.crop_id==crop_id)
    if market_id: q=q.where(MarketPrice.market_id==market_id)
    prices=db.scalars(q.order_by(MarketPrice.date.desc())).all()
    return _response([{"id":p.id,"market_id":p.market_id,"crop_id":p.crop_id,"date":str(p.date),"price_per_kg":p.price_per_kg,"demand_level":p.demand_level} for p in prices])

@router.get("/forecast")
def market_forecast(crop_id:int, market_id:int, forecast_days:int=Query(7,ge=1,le=30), db:Session=Depends(get_db)):
    prices=db.scalars(select(MarketPrice).where(MarketPrice.crop_id==crop_id,MarketPrice.market_id==market_id).order_by(MarketPrice.date)).all()
    if not prices: raise HTTPException(404,"Insufficient price data")
    average=sum(p.price_per_kg for p in prices[-5:])/min(5,len(prices)); spread=max(.5,average*.08)
    return _response({"crop_id":crop_id,"market_id":market_id,"forecast":[{"date":str(date.today()+timedelta(days=i)),"predicted_price":round(average,2),"lower_bound":round(average-spread,2),"upper_bound":round(average+spread,2)} for i in range(1,forecast_days+1)],"model_type":"moving-average-baseline","model_version":"baseline-v1","data_date_range":{"start":str(prices[0].date),"end":str(prices[-1].date)},"note":"Baseline decision support only."})

@router.post("/recommend")
def recommend_markets(body:MarketRequest,user=Depends(farmer_only),db:Session=Depends(get_db)):
    harvest=db.scalar(select(Harvest).where(Harvest.id==body.harvest_id,Harvest.farmer_id==user.id))
    if not harvest: raise HTTPException(404,"Harvest not found")
    result=MarketRankingService.rank(db,harvest)
    if not result: raise HTTPException(404,"No market data available for this crop")
    return _response({"markets":result},"Markets ranked by estimated net realization")

@router.get("/{market_id}")
def market_detail(market_id:int,db:Session=Depends(get_db)):
    market=db.get(Market,market_id)
    if not market: raise HTTPException(404,"Market not found")
    return _response({"id":market.id,"name":market.name,"location_name":market.location_name,"latitude":market.latitude,"longitude":market.longitude,"market_charge_per_kg":market.market_charge_per_kg,"transport_base_cost":market.transport_base_cost})
