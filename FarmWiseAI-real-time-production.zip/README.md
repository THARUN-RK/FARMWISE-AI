# FarmWise AI — Production-ready farm-to-market app

FarmWise AI is a React/Vite frontend backed by a FastAPI API and PostgreSQL/SQLite-compatible persistence. The application is designed for real authenticated users: farm data is stored per account, weather comes from a live provider, and live mandi quotes can come from data.gov.in/AGMARKNET when configured.

## Production architecture

`Browser → Vite/React frontend → FastAPI backend → PostgreSQL`

The backend owns all private provider credentials. Weather and market requests use connection reuse plus short TTL caching to reduce latency and external API load.

## Live services

- **Weather:** Open-Meteo, no API key required.
- **Mandi prices:** data.gov.in/AGMARKNET, requires `MARKET_DATA_API_KEY`.
- **AI Advisor:** configurable OpenAI-compatible provider, requires `AI_API_KEY` and a supported `AI_MODEL`.

The app never fabricates live weather or market data when a provider is unavailable.

## Frontend

```bash
npm ci
npm run build
```

For local development:

```bash
npm run dev
```

Set `VITE_API_URL` to the deployed API base, for example:

`https://your-api.example.com/api/v1`

GitHub Pages is supported by the included workflow. Add `VITE_API_URL` as a GitHub Actions repository variable before deployment.

## Backend

```bash
cd backend
python -m venv .venv
# activate the environment
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload
```

For production, use PostgreSQL and a strong generated `JWT_SECRET`. Never commit `.env` or provider credentials.

### Required production variables

- `DATABASE_URL`
- `JWT_SECRET`
- `CORS_ORIGINS` — include the exact frontend origin
- `AI_API_KEY`
- `AI_BASE_URL`
- `AI_MODEL`
- `MARKET_DATA_API_KEY`
- `MARKET_DATA_URL`
- `MARKET_CACHE_SECONDS`

Weather requires no credential.

## Important production behavior

- Demo mode is disabled.
- New users can register only as `farmer` or `buyer`; admin is not self-assignable.
- Farm, harvest and recommendation records are scoped to the authenticated user.
- Weather is refreshed automatically in the client every 10 minutes and cached server-side for 10 minutes.
- Live market responses are cached for 5 minutes by default.
- AI requests are rate-limited per user.
- API keys stay on the backend.
- Provider failures return explicit errors rather than fake values.

## Deployment

The included `backend/render.yaml` provisions a FastAPI service and PostgreSQL database. Add the secret AI and market variables in the hosting dashboard. Deploy the frontend separately with GitHub Pages or another static host, then set its `VITE_API_URL` to the production API.

Before public launch, configure a real production domain, HTTPS, CORS, provider credentials, database backups, monitoring and a privacy/terms policy.
