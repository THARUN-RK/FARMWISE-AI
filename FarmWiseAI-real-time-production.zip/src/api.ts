const configuredApiUrl = (import.meta.env.VITE_API_URL ?? "").replace(/\/$/, "");
const API_BASE = configuredApiUrl || (import.meta.env.DEV ? "http://127.0.0.1:8000/api/v1" : "");
if (!API_BASE && !import.meta.env.DEV) {
  console.warn("FarmWise API is not configured. Set VITE_API_URL in the production build environment.");
}

export type User = {
  id: number;
  name: string;
  phone: string;
  email?: string | null;
  role: string;
  language?: string;
  location_name?: string | null;
  state?: string | null;
  district?: string | null;
  latitude?: number | null;
  longitude?: number | null;
  created_at?: string | null;
};

export type Farm = {
  id: number;
  land_size_acres: number;
  soil_type: string;
  water_availability: string;
  current_season: string;
  budget: number;
  previous_crop?: string | null;
};

export type ApiCrop = {
  crop_id: number;
  crop: string;
  score: number;
  risk: string;
  expected_profit_per_acre: number;
  reasons: string[];
  explanation: string;
};

async function request<T>(
  path: string,
  options: RequestInit = {},
  token?: string,
): Promise<T> {
  if (!API_BASE) {
    throw new Error("FarmWise API is not configured. Set VITE_API_URL for the deployed application.");
  }
  let response: Response;
  try {
    response = await fetch(`${API_BASE}${path}`, {
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
        ...(options.headers ?? {}),
      },
    });
  } catch {
    throw new Error("FarmWise API is not reachable. Start the backend locally or configure VITE_API_URL for the deployed app.");
  }
  const body = await response.json().catch(() => ({}));
  if (!response.ok)
    throw new Error(
      body?.detail?.message ??
        body?.detail ??
        body?.message ??
        "Request failed",
    );
  return body.data ?? body;
}

export const api = {
  login: (identifier: string, password: string) =>
    request<{ access_token: string; user: User }>("/auth/login", {
      method: "POST",
      body: JSON.stringify({ identifier, password }),
    }),
  register: (payload: {
    name: string;
    phone: string;
    email: string;
    password: string;
    confirm_password: string;
    role: string;
    state: string;
    district: string;
  }) =>
    request<{ access_token: string; user: User }>("/auth/register", {
      method: "POST",
      body: JSON.stringify(payload),
    }),
  me: (token: string) => request<User>("/auth/me", {}, token),
  updateProfile: (payload: { name: string; language: string; location_name?: string | null; latitude?: number | null; longitude?: number | null; state?: string | null; district?: string | null }, token: string) => request<User>("/farmers/profile", { method: "PUT", body: JSON.stringify(payload) }, token),
  farms: (token: string) => request<Farm[]>("/farms", {}, token),
  createFarm: (payload: Omit<Farm, "id">, token: string) => request<Farm>("/farms", { method: "POST", body: JSON.stringify(payload) }, token),
  updateFarm: (id: number, payload: Omit<Farm, "id">, token: string) => request<Farm>(`/farms/${id}`, { method: "PUT", body: JSON.stringify(payload) }, token),
  recommendations: (farmId: number, token: string) =>
    request<{ recommendations: ApiCrop[] }>(
      `/recommendations/crops`,
      { method: "POST", body: JSON.stringify({ farm_id: farmId }) },
      token,
    ),
  weatherCurrent: (token: string) =>
    request<{ temperature_c: number; humidity_percent: number; precipitation_mm: number; wind_speed_kmh: number; description: string; weather_code: number }>("/weather/current", {}, token),
  weatherForecast: (token: string) =>
    request<{ forecast: Array<{ date: string; temp_max_c: number; temp_min_c: number; precipitation_mm: number; rain_probability_percent: number; description: string }> }>("/weather/forecast", {}, token),
  aiChat: (message: string, token: string) =>
    request<{ message: string; model: string }>("/ai/chat", { method: "POST", body: JSON.stringify({ message }) }, token),
  harvests: (token: string) =>
    request<Array<{ id: number; crop_id: number; quantity_tonnes: number; grade: string; harvest_date: string; notes?: string | null }>>("/harvests", {}, token),
  createHarvest: (payload: { crop_id: number; quantity_tonnes: number; grade: string; harvest_date: string; notes?: string }, token: string) =>
    request<{ id: number; crop_id: number; quantity_tonnes: number; grade: string; harvest_date: string }>("/harvests", { method: "POST", body: JSON.stringify(payload) }, token),
  deleteFarm: (id: number, token: string) =>
    request<void>(`/farms/${id}`, { method: "DELETE" }, token),
  markets: () =>
    request<Array<{ id: number; name: string; location_name: string }>>(
      "/markets",
    ),
  liveMarkets: (commodity: string, token: string) =>
    request<{ commodity: string; markets: Array<{ market_id: number; market: string; location_name: string; price_per_kg: number; distance_km: number | null; transport_cost_per_kg: number | null; market_charges_per_kg: number | null; net_realization_per_kg: number | null; demand: string; arrival_date?: string | null; provider: string; fetched_at: number }> }>
      (`/markets/live/ranked?commodity=${encodeURIComponent(commodity)}`, {}, token),
  alerts: (token: string) => request<Array<{ type: string; severity: string; message: string }>>("/alerts", {}, token),
  dashboardImpact: (token: string) => request<{ farm_acres: number; expected_net_realization: number; expected_farmer_profit: number; transport_cost_per_kg: number; estimated_selling_delay_days: number; post_harvest_loss_assumption_percent: number; water_efficiency_index: number; input_efficiency_index: number; harvest_count: number; enquiry_count: number; completed_deals: number; top_crop_score: number | null; data_label: string }>("/dashboard/impact", {}, token),
  buyers: () =>
    request<
      Array<{
        id: number;
        name: string;
        business_type: string;
        location_name: string;
        verification_status: string;
      }>
    >("/buyers"),
};

export function saveToken(token: string) {
  localStorage.setItem("farmwise_access_token", token);
}
export function getToken() {
  return localStorage.getItem("farmwise_access_token");
}
export function clearToken() {
  localStorage.removeItem("farmwise_access_token");
}
