# FarmWise AI Backend

Production-oriented MVP backend for **India-Realistic Crop-to-Market Decision Intelligence**. The API connects farm inputs to crop recommendations, sowing windows, harvests, net-realization market ranking, buyer matching, enquiries, profit estimates, alerts, weather, and impact metrics — all live, computed from the database and (for weather) the Open-Meteo API.

Seeded crop/market/buyer records come from `scripts/seed_database.py` and are stored as ordinary rows; nothing in the API is hardcoded or faked at request time. Every number returned is a computed estimate from real inputs, and is labeled as such — not a live market quote or an agronomic guarantee.

## Architecture

FastAPI routes are backed by SQLAlchemy 2.x models and focused service engines in `app/services/engines.py`. PostgreSQL is the Docker target; SQLite is the default local fallback for quick tests. JWT bearer auth supports farmer, buyer, and admin roles. Crop, market, and buyer decisions are deterministic and explainable (each response includes plain-language `reasons`).

## Run locally

```powershell
cd backend
python -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
$env:DATABASE_URL = "sqlite:///./farmwise.db" # omit when using .env/Postgres
.venv\Scripts\python.exe scripts\seed_database.py
.venv\Scripts\python.exe -m uvicorn app.main:app --reload --port 8000
```

Swagger is available at `http://localhost:8000/docs`; OpenAPI JSON is at `/openapi.json`.

## Docker/Postgres

```powershell
cd backend
docker compose up --build
```

The container API is available at `http://localhost:8000`. Set `DATABASE_URL` and `JWT_SECRET` from `.env.example` in real environments. Do not commit secrets.

## Main endpoints

- `POST /api/v1/auth/register`, `POST /api/v1/auth/login`, `GET /api/v1/auth/me`, `PUT /api/v1/auth/profile`
- `GET /api/v1/crops` — full crop catalog (for dropdowns/forms)
- `POST|GET /api/v1/farms`, `PUT /api/v1/farms/{id}`
- `POST /api/v1/recommendations/crops`
- `GET /api/v1/recommendations/sowing-window/{crop_id}`
- `POST|GET /api/v1/harvests`
- `GET /api/v1/markets`, `GET /api/v1/markets/prices`, `POST /api/v1/markets/recommend`, `GET /api/v1/markets/forecast`
- `GET /api/v1/buyers`, `POST /api/v1/buyers/match`
- `POST|GET /api/v1/enquiries`, `PATCH /api/v1/enquiries/{id}/status`
- `POST /api/v1/profit/calculate`
- `GET /api/v1/weather/current`, `GET /api/v1/weather/forecast` (live Open-Meteo data by the user's saved coordinates), `GET /api/v1/alerts`
- `GET /api/v1/dashboard/impact` — per-account computed profit/efficiency summary
- `GET /api/v1/admin/analytics`

All success payloads follow `{ success, data, message }`; validation and domain errors use FastAPI HTTP status codes.

**Route prefixes:** every router file (e.g. `auth.py`, `farms.py`) already declares its own prefix (`/auth`, `/farms`, etc). `main.py` mounts each router with only the shared `/api/v1` prefix — do not add a second copy of a router's own prefix when registering it, or you will get silently-unreachable duplicated paths (e.g. `/api/v1/auth/auth/login`).

## Seeded account

After seeding: phone `+919999999999`, password `DemoPass123!`. This is a real, ordinary seeded account — useful to explore the app immediately without registering your own.

Example:

```powershell
$login = Invoke-RestMethod http://localhost:8000/api/v1/auth/login -Method Post -ContentType 'application/json' -Body '{"identifier":"+919999999999","password":"DemoPass123!"}'
$headers = @{ Authorization = "Bearer $($login.data.access_token)" }
Invoke-RestMethod http://localhost:8000/api/v1/farms -Headers $headers
```

## Migrations, tests, and ML roadmap

The SQLAlchemy metadata can be used to initialize Alembic. For a production migration workflow, configure `alembic/env.py` with `Base.metadata` and run `alembic revision --autogenerate` then `alembic upgrade head`. The current MVP uses a transparent rules-based baseline (`model_version: "rules-v1"`); future training can add `app/ml` and persist a versioned model after evaluating sufficient historical data.

Run tests with:

```powershell
.venv\Scripts\python.exe -m pytest -q
```

## Known limitations

Weather comes live from Open-Meteo (no API key required) using the farmer's saved latitude/longitude, with a sensible default location if none is set — accuracy depends on that location being current. Market prices and buyer requirements are seeded reference data rather than a live mandi/APMC feed; swapping in a real market-data provider is the natural next step before production use. Add an Alembic environment, role-specific buyer/admin workflows, rate limiting, and structured JSON logging before production deployment.
