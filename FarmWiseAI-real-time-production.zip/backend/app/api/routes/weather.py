"""Fast, cached weather API for each authenticated farmer location."""
import logging, time
from typing import Any
from fastapi import APIRouter, Depends, HTTPException
from app.api.deps import current_user
from app.core.http_client import get_http_client
from app.models.entities import Farmer

log=logging.getLogger("farmwise.weather")
router=APIRouter(prefix="/weather",tags=["weather"])
_cache:dict[str,tuple[float,Any]]={}
TTL=600
URL="https://api.open-meteo.com/v1/forecast"
CODES={0:"Clear sky",1:"Mainly clear",2:"Partly cloudy",3:"Overcast",45:"Fog",48:"Rime fog",51:"Light drizzle",53:"Moderate drizzle",55:"Dense drizzle",61:"Slight rain",63:"Moderate rain",65:"Heavy rain",71:"Slight snow",73:"Moderate snow",75:"Heavy snow",80:"Slight showers",81:"Moderate showers",82:"Violent showers",95:"Thunderstorm",96:"Thunderstorm with hail",99:"Thunderstorm with heavy hail"}

def _cached(key):
    item=_cache.get(key)
    return item[1] if item and time.time()-item[0]<TTL else None

async def _fetch(lat:float,lon:float):
    key=f"{lat:.3f},{lon:.3f}"; cached=_cached(key)
    if cached: return cached
    params={"latitude":lat,"longitude":lon,"current":"temperature_2m,relative_humidity_2m,precipitation,wind_speed_10m,weather_code","daily":"temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max,weather_code","timezone":"auto","forecast_days":7}
    try:
        client=await get_http_client(); r=await client.get(URL,params=params); r.raise_for_status(); raw=r.json()
    except Exception as exc:
        log.warning("weather provider failure: %s",exc); raise HTTPException(503,"Weather service is temporarily unavailable. Please try again.") from exc
    cur=raw.get("current",{}); daily=raw.get("daily",{}); times=daily.get("time",[])
    result={"provider":"Open-Meteo","fetched_at":time.time(),"latitude":lat,"longitude":lon,"current":{"temperature_c":cur.get("temperature_2m"),"humidity_percent":cur.get("relative_humidity_2m"),"precipitation_mm":cur.get("precipitation"),"wind_speed_kmh":cur.get("wind_speed_10m"),"weather_code":cur.get("weather_code"),"description":CODES.get(cur.get("weather_code"),"Unknown")},"forecast":[]}
    for i,d in enumerate(times):
        result["forecast"].append({"date":d,"temp_max_c":daily["temperature_2m_max"][i],"temp_min_c":daily["temperature_2m_min"][i],"precipitation_mm":daily["precipitation_sum"][i],"rain_probability_percent":daily["precipitation_probability_max"][i],"weather_code":daily["weather_code"][i],"description":CODES.get(daily["weather_code"][i],"Unknown")})
    _cache[key]=(time.time(),result); return result

def _coords(user:Farmer):
    if user.latitude is None or user.longitude is None: raise HTTPException(422,"Add your farm location in Profile to use live weather.")
    return user.latitude,user.longitude

@router.get("/current")
async def current_weather(user:Farmer=Depends(current_user)):
    lat,lon=_coords(user); d=await _fetch(lat,lon); return {"success":True,"data":{**d["current"],"provider":d["provider"],"fetched_at":d["fetched_at"]}}

@router.get("/forecast")
async def weather_forecast(user:Farmer=Depends(current_user)):
    lat,lon=_coords(user); d=await _fetch(lat,lon); return {"success":True,"data":{"forecast":d["forecast"],"provider":d["provider"],"fetched_at":d["fetched_at"]}}
