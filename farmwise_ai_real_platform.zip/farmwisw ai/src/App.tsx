import { createContext, useContext, useEffect, useMemo, useState } from "react";
import {
  api,
  clearToken,
  getToken,
  saveToken,
  type ApiBuyerMatch,
  type ApiCrop,
  type ApiMarketRank,
  type CropCatalogItem,
  type DashboardImpact,
  type Enquiry,
  type Farm,
  type Harvest,
  type User,
  type WeatherCurrent,
  type WeatherForecastDay,
} from "./api";

type Module =
  | "Dashboard"
  | "My Farm"
  | "Crop Planner"
  | "Market Intelligence"
  | "Buyers & Brokers"
  | "My Harvest"
  | "Analytics"
  | "Profile";
type Language = "en" | "kn" | "te" | "ta";
const LanguageContext = createContext<{ language: Language; setLanguage: (language: Language) => void }>({ language: "en", setLanguage: () => undefined });
const translations: Record<Language, Record<string, string>> = {
  en: { dashboard: "Dashboard", farm: "My Farm", planner: "Crop Planner", markets: "Market Intelligence", buyers: "Buyers & Brokers", harvest: "My Harvest", analytics: "Analytics", profile: "Profile", login: "Log in", signup: "Get started", greeting: "Good morning", cropPlan: "What should I grow?", marketPlan: "Where should you sell?" },
  kn: { dashboard: "ಡ್ಯಾಶ್‌ಬೋರ್ಡ್", farm: "ನನ್ನ ಜಮೀನು", planner: "ಬೆಳೆ ಯೋಜಕ", markets: "ಮಾರುಕಟ್ಟೆ ಮಾಹಿತಿ", buyers: "ಖರೀದಿದಾರರು ಮತ್ತು ದಲ್ಲಾಳಿಗಳು", harvest: "ನನ್ನ ಕೊಯ್ಲು", analytics: "ವಿಶ್ಲೇಷಣೆ", profile: "ಪ್ರೊಫೈಲ್", login: "ಲಾಗಿನ್", signup: "ಪ್ರಾರಂಭಿಸಿ", greeting: "ಶುಭೋದಯ", cropPlan: "ನಾನು ಏನು ಬೆಳೆಯಬೇಕು?", marketPlan: "ನಾನು ಎಲ್ಲಿ ಮಾರಾಟ ಮಾಡಬೇಕು?" },
  te: { dashboard: "డాష్‌బోర్డ్", farm: "నా పొలం", planner: "పంట ప్రణాళిక", markets: "మార్కెట్ సమాచారం", buyers: "కొనుగోలుదారులు మరియు బ్రోకర్లు", harvest: "నా పంట", analytics: "విశ్లేషణ", profile: "ప్రొఫైల్", login: "లాగిన్", signup: "ప్రారంభించండి", greeting: "శుభోదయం", cropPlan: "నేను ఏమి పండించాలి?", marketPlan: "నేను ఎక్కడ అమ్మాలి?" },
  ta: { dashboard: "டாஷ்போர்டு", farm: "என் பண்ணை", planner: "பயிர் திட்டமிடல்", markets: "சந்தை தகவல்", buyers: "வாங்குபவர்கள் மற்றும் தரகர்கள்", harvest: "என் அறுவடை", analytics: "பகுப்பாய்வு", profile: "சுயவிவரம்", login: "உள்நுழை", signup: "தொடங்குங்கள்", greeting: "காலை வணக்கம்", cropPlan: "நான் என்ன பயிரிட வேண்டும்?", marketPlan: "நான் எங்கே விற்க வேண்டும்?" },
};
function useLanguage() { const context = useContext(LanguageContext); return { ...context, t: (key: string) => translations[context.language][key] ?? translations.en[key] ?? key }; }

// A crop recommendation as displayed in the UI, built from the live API
// recommendation plus the crop catalog (both real backend data).
type DisplayCrop = {
  id: number;
  name: string;
  score: number;
  yieldLabel: string;
  costLabel: string;
  profit: string;
  risk: string;
  water: string;
  image: string;
  reason: string;
  reasons: string[];
  reasonCodes?: ApiCrop["reason_codes"];
};

const CROP_IMAGES: Record<string, string> = {
  groundnut: "https://images.unsplash.com/photo-1589923188900-85dae523342b?auto=format&fit=crop&w=700&q=80",
  chilli: "https://images.unsplash.com/photo-1588252303782-cb80119abd6d?auto=format&fit=crop&w=700&q=80",
  tomato: "https://images.unsplash.com/photo-1546094096-0df4bcaaa337?auto=format&fit=crop&w=700&q=80",
  onion: "https://images.unsplash.com/photo-1508747703725-719777637510?auto=format&fit=crop&w=700&q=80",
  maize: "https://images.unsplash.com/photo-1601472543098-2b17bd0b9ffa?auto=format&fit=crop&w=700&q=80",
  paddy: "https://images.unsplash.com/photo-1568158879083-c42860933ed7?auto=format&fit=crop&w=700&q=80",
  cotton: "https://images.unsplash.com/photo-1620200423727-8127f75d7f53?auto=format&fit=crop&w=700&q=80",
  potato: "https://images.unsplash.com/photo-1518977676601-b53f82aba655?auto=format&fit=crop&w=700&q=80",
  turmeric: "https://images.unsplash.com/photo-1615485500704-8e990f9900f7?auto=format&fit=crop&w=700&q=80",
  sugarcane: "https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&w=700&q=80",
  default: "https://images.unsplash.com/photo-1500937386664-56d1dfef3854?auto=format&fit=crop&w=700&q=80",
};

const navItems: { label: Module; icon: string }[] = [
  { label: "Dashboard", icon: "⌂" },
  { label: "My Farm", icon: "⌁" },
  { label: "Crop Planner", icon: "✦" },
  { label: "Market Intelligence", icon: "↗" },
  { label: "Buyers & Brokers", icon: "♧" },
  { label: "My Harvest", icon: "◒" },
  { label: "Analytics", icon: "▥" },
  { label: "Profile", icon: "◎" },
];
const navTranslationKeys: Record<string, string> = { Dashboard: "dashboard", "My Farm": "farm", "Crop Planner": "planner", "Market Intelligence": "markets", "Buyers & Brokers": "buyers", "My Harvest": "harvest", Analytics: "analytics", Profile: "profile" };

function formatDate(value?: string | null) {
  if (!value) return "—";
  try { return new Date(value).toLocaleDateString("en-IN", { day: "numeric", month: "short" }); }
  catch { return value; }
}
function initialsOf(name: string) {
  return name.split(/\s+/).filter(Boolean).slice(0, 2).map((part) => part[0]).join("").toUpperCase() || "?";
}

function App() {
  const [authenticated, setAuthenticated] = useState(false),
    [authMode, setAuthMode] = useState<"login" | "signup" | null>(null),
    [authLoading, setAuthLoading] = useState(true);
  const [language, setLanguage] = useState<Language>(() => (localStorage.getItem("farmwise_language") as Language) || "en");
  const [user, setUser] = useState<User | null>(null),
    [farm, setFarm] = useState<Farm | null>(null),
    [apiRecommendations, setApiRecommendations] = useState<ApiCrop[]>([]),
    [cropCatalog, setCropCatalog] = useState<CropCatalogItem[]>([]);
  const [harvests, setHarvests] = useState<Harvest[]>([]),
    [activeHarvestId, setActiveHarvestId] = useState<number | null>(null),
    [marketRanking, setMarketRanking] = useState<ApiMarketRank[]>([]),
    [buyerMatches, setBuyerMatches] = useState<ApiBuyerMatch[]>([]),
    [enquiries, setEnquiries] = useState<Enquiry[]>([]);
  const [weatherCurrent, setWeatherCurrent] = useState<WeatherCurrent | null>(null),
    [weatherForecast, setWeatherForecast] = useState<WeatherForecastDay[]>([]),
    [weatherError, setWeatherError] = useState(false),
    [dashboardImpact, setDashboardImpact] = useState<DashboardImpact | null>(null),
    [sowingWindow, setSowingWindow] = useState<{ start: string; end: string } | null>(null);
  const [active, setActive] = useState<Module>("Dashboard"),
    [menuOpen, setMenuOpen] = useState(false),
    [previewOpen, setPreviewOpen] = useState(false);
  const [toast, setToast] = useState(""),
    [enquiryBuyer, setEnquiryBuyer] = useState<ApiBuyerMatch | null>(null),
    [enquirySending, setEnquirySending] = useState(false),
    [plannerLoading, setPlannerLoading] = useState(false);
  const [selectedCropId, setSelectedCropId] = useState<number | null>(null),
    [water, setWater] = useState("Medium"),
    [soil, setSoil] = useState("Loamy"),
    [landSize, setLandSize] = useState(2),
    [budget, setBudget] = useState(50000),
    [season, setSeason] = useState("Kharif"),
    [previousCrop, setPreviousCrop] = useState(""),
    [quantity, setQuantity] = useState("2");

  const changeLanguage = (nextLanguage: Language) => { setLanguage(nextLanguage); localStorage.setItem("farmwise_language", nextLanguage); };
  const notify = (message: string) => { setToast(message); window.setTimeout(() => setToast(""), 2800); };

  const refreshHarvestDerived = async (harvestId: number, token: string) => {
    const [marketResult, buyerResult] = await Promise.all([
      api.recommendMarkets(harvestId, token).catch(() => ({ markets: [] as ApiMarketRank[] })),
      api.matchBuyers(harvestId, token).catch(() => ({ buyers: [] as ApiBuyerMatch[] })),
    ]);
    setMarketRanking(marketResult.markets);
    setBuyerMatches(buyerResult.buyers);
  };

  const loadAccount = async (token: string) => {
    const currentUser = await api.me(token);
    setUser(currentUser);
    setAuthenticated(true);
    setActive(currentUser.role === "buyer" ? "Buyers & Brokers" : "Dashboard");

    const catalog = await api.cropCatalog().catch(() => [] as CropCatalogItem[]);
    setCropCatalog(catalog);

    if (currentUser.role !== "buyer") {
      const farms = await api.farms(token).catch(() => [] as Farm[]);
      const currentFarm = farms[0] ?? null;
      setFarm(currentFarm);
      if (currentFarm) {
        setSoil(currentFarm.soil_type);
        setWater(currentFarm.water_availability);
        setLandSize(currentFarm.land_size_acres);
        setBudget(currentFarm.budget);
        setSeason(currentFarm.current_season);
        setPreviousCrop(currentFarm.previous_crop ?? "");
        const result = await api.recommendations(currentFarm.id, token).catch(() => ({ recommendations: [] as ApiCrop[], model_version: "" }));
        setApiRecommendations(result.recommendations);
        if (result.recommendations[0]) setSelectedCropId(result.recommendations[0].crop_id);
      }

      const harvestList = await api.harvests(token).catch(() => [] as Harvest[]);
      setHarvests(harvestList);
      const latest = harvestList[harvestList.length - 1] ?? null;
      if (latest) {
        setActiveHarvestId(latest.id);
        await refreshHarvestDerived(latest.id, token);
      }

      const impact = await api.dashboardImpact(token).catch(() => null);
      setDashboardImpact(impact);
    }

    const enquiryList = await api.enquiries(token).catch(() => [] as Enquiry[]);
    setEnquiries(enquiryList);

    try {
      const [current, forecast] = await Promise.all([api.weatherCurrent(token), api.weatherForecast(token)]);
      setWeatherCurrent(current);
      setWeatherForecast(forecast.forecast);
      setWeatherError(false);
    } catch {
      setWeatherError(true);
    }
  };

  const saveFarm = async (payload: Omit<Farm, "id">) => {
    const token = getToken();
    if (!token) throw new Error("Your session has expired. Please log in again.");
    const saved = farm ? await api.updateFarm(farm.id, payload, token) : await api.createFarm(payload, token);
    setFarm(saved);
    setLandSize(saved.land_size_acres);
    setBudget(saved.budget);
    setSeason(saved.current_season);
    setPreviousCrop(saved.previous_crop ?? "");
    const result = await api.recommendations(saved.id, token);
    setApiRecommendations(result.recommendations);
    if (result.recommendations[0]) setSelectedCropId(result.recommendations[0].crop_id);
    notify("Farm profile saved and recommendations refreshed.");
  };

  const recordHarvest = async (payload: { crop_id: number; quantity_tonnes: number; grade: string; harvest_date: string }) => {
    const token = getToken();
    if (!token) throw new Error("Your session has expired. Please log in again.");
    const saved = await api.createHarvest(payload, token);
    setHarvests((prev) => [...prev, saved]);
    setActiveHarvestId(saved.id);
    await refreshHarvestDerived(saved.id, token);
    notify("Harvest recorded. Market and buyer matches are ready.");
  };

  const submitEnquiry = async (message: string, offeredPrice: number, quantityTonnes: number) => {
    const token = getToken();
    if (!token || !enquiryBuyer || !activeHarvestId) return;
    setEnquirySending(true);
    try {
      const created = await api.sendEnquiry({ buyer_id: enquiryBuyer.buyer_id, harvest_id: activeHarvestId, quantity_tonnes: quantityTonnes, offered_price: offeredPrice, message }, token);
      setEnquiries((prev) => [...prev, created]);
      notify("Enquiry sent successfully.");
      setEnquiryBuyer(null);
    } catch (submitError) {
      notify(submitError instanceof Error ? submitError.message : "Could not send enquiry.");
    } finally {
      setEnquirySending(false);
    }
  };

  useEffect(() => {
    const token = getToken();
    if (!token) { setAuthLoading(false); return; }
    loadAccount(token).catch(() => clearToken()).finally(() => setAuthLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const token = getToken();
    if (!token || !selectedCropId || !authenticated) { setSowingWindow(null); return; }
    let cancelled = false;
    api.sowingWindow(selectedCropId, season, token)
      .then((result) => { if (!cancelled) setSowingWindow(result.sowing_window); })
      .catch(() => { if (!cancelled) setSowingWindow(null); });
    return () => { cancelled = true; };
  }, [selectedCropId, season, authenticated]);

  const rankedCrops = useMemo<DisplayCrop[]>(
    () => apiRecommendations.map((item) => {
      const catalogEntry = cropCatalog.find((c) => c.name.toLowerCase() === item.crop.toLowerCase());
      return {
        id: item.crop_id,
        name: item.crop,
        score: item.score,
        yieldLabel: catalogEntry ? `${catalogEntry.expected_yield_per_acre.toLocaleString("en-IN")} kg / acre` : "Catalog estimate",
        costLabel: catalogEntry ? `INR ${catalogEntry.base_production_cost_per_acre.toLocaleString("en-IN")}` : "Catalog estimate",
        profit: `INR ${item.expected_profit_per_acre.toLocaleString("en-IN")}`,
        risk: item.risk,
        water: catalogEntry?.water_requirement ?? farm?.water_availability ?? "Unknown",
        image: CROP_IMAGES[item.crop.toLowerCase()] ?? CROP_IMAGES.default,
        reason: item.explanation,
        reasons: item.reasons,
        reasonCodes: item.reason_codes,
      };
    }),
    [apiRecommendations, cropCatalog, farm],
  );
  const selectedCrop = useMemo(() => rankedCrops.find((c) => c.id === selectedCropId) ?? rankedCrops[0] ?? null, [rankedCrops, selectedCropId]);
  const activeHarvest = useMemo(() => harvests.find((h) => h.id === activeHarvestId) ?? null, [harvests, activeHarvestId]);
  const cropNameById = (cropId: number) => cropCatalog.find((c) => c.id === cropId)?.name ?? `Crop #${cropId}`;
  const sentBuyerIds = useMemo(() => new Set(enquiries.map((e) => e.buyer_id)), [enquiries]);

  const refreshWorkspace = async () => {
    const token = getToken();
    if (!token) return;
    await loadAccount(token);
    notify("Workspace refreshed with your latest account data.");
  };

  const generatePlan = async () => {
    setPlannerLoading(true);
    try {
      await saveFarm({ land_size_acres: landSize, soil_type: soil, water_availability: water, current_season: season, budget, previous_crop: previousCrop || null });
      setActive("Crop Planner");
    } catch (planError) {
      notify(planError instanceof Error ? planError.message : "Could not refresh recommendations.");
    } finally {
      setPlannerLoading(false);
    }
  };

  if (authLoading)
    return (
      <LanguageContext.Provider value={{ language, setLanguage: changeLanguage }}>
        <div className="loading-screen"><span className="spinner" /> Loading your FarmWise workspace...</div>
      </LanguageContext.Provider>
    );
  if (!authenticated)
    return (
      <LanguageContext.Provider value={{ language, setLanguage: changeLanguage }}>
        <Landing
          authMode={authMode}
          setAuthMode={setAuthMode}
          onLogin={async (identifier, password) => {
            const result = await api.login(identifier, password);
            saveToken(result.access_token);
            await loadAccount(result.access_token);
            setAuthMode(null);
          }}
          onSignup={async (payload) => {
            const result = await api.register(payload);
            saveToken(result.access_token);
            await loadAccount(result.access_token);
            setAuthMode(null);
          }}
          onBrowse={() => setPreviewOpen(true)}
        />
        {previewOpen && <PublicPreviewModal onClose={() => setPreviewOpen(false)} onSignup={() => { setPreviewOpen(false); setAuthMode("signup"); }} />}
      </LanguageContext.Provider>
    );
  return (
    <LanguageContext.Provider value={{ language, setLanguage: changeLanguage }}>
      <div className="product-shell">
        <aside className={menuOpen ? "app-sidebar open" : "app-sidebar"}>
          <div className="brand">
            <span className="brand-symbol">FW</span>
            <span>FarmWise <b>AI</b></span>
          </div>
          <div className="sidebar-profile">
            <div className="profile-avatar">{user?.name?.slice(0, 2).toUpperCase()}</div>
            <div>
              <strong>{user?.name}</strong>
              <small>{user?.role === "buyer" ? "Buyer account" : "Farmer account"}</small>
            </div>
            <span className="online-dot" />
          </div>
          <p className="nav-caption">WORKSPACE</p>
          <nav>
            {navItems.map((item) => (
              <button key={item.label} className={active === item.label ? "app-nav active" : "app-nav"} onClick={() => { setActive(item.label); setMenuOpen(false); }}>
                <span>{item.icon}</span>
                {translations[language][navTranslationKeys[item.label]]}
                {item.label === "Dashboard" && <i />}
              </button>
            ))}
          </nav>
          <p className="nav-caption lower">ACCOUNT</p>
          <nav>
            <button className="app-nav" onClick={() => notify(`You have ${enquiries.length} enquir${enquiries.length === 1 ? "y" : "ies"} on record.`)}>
              <span>♢</span>Notifications <b className="count">{enquiries.length}</b>
            </button>
            <button className="app-nav" onClick={() => notify("Settings are available in the next release.")}>
              <span>⚙</span>Settings
            </button>
          </nav>
          <div className="sidebar-bottom">
            <div className="season-card">
              <small>CURRENT SEASON</small>
              <strong>{farm?.current_season ?? "No farm season yet"}</strong>
              <span>{farm ? "Farm profile connected" : "Complete your farm profile"}</span>
              <div><i /></div>
            </div>
            <button className="help-button" onClick={() => notify("FarmWise support is ready to help.")}>
              ? <span>Help & guidance</span>
            </button>
            <button
              className="logout-button"
              onClick={() => {
                clearToken();
                setUser(null); setFarm(null); setAuthenticated(false); setApiRecommendations([]);
                setHarvests([]); setActiveHarvestId(null); setMarketRanking([]); setBuyerMatches([]);
                setEnquiries([]); setWeatherCurrent(null); setWeatherForecast([]); setDashboardImpact(null);
              }}
            >
              <span>↪</span> Log out
            </button>
          </div>
        </aside>
        <main className="app-main">
          <header className="app-header">
            <button className="mobile-menu" onClick={() => setMenuOpen(!menuOpen)}>☰</button>
            <div className="breadcrumbs"><span>Workspace</span><b>/</b><strong>{active}</strong></div>
            <div className="header-actions">
              <span className="sync-status"><i />Connected to FarmWise API</span>
              <button className="header-icon" onClick={() => notify(`You have ${enquiries.length} enquir${enquiries.length === 1 ? "y" : "ies"} on record.`)} aria-label="Notifications">♢<i /></button>
              <select className="lang-button" value={language} onChange={(event) => changeLanguage(event.target.value as Language)} aria-label="Language"><option value="en">EN</option><option value="kn">ಕನ್ನಡ</option><option value="te">తెలుగు</option><option value="ta">தமிழ்</option></select>
              <div className="header-user">
                <div className="profile-avatar small">{user?.name?.slice(0, 2).toUpperCase()}</div>
                <span>{user?.name}⌄</span>
              </div>
            </div>
          </header>
          <div className="page-body">
            {active === "Dashboard" && (
              <Dashboard
                user={user} farm={farm} go={setActive}
                rankedCrops={rankedCrops} marketRanking={marketRanking} buyerMatches={buyerMatches}
                weatherCurrent={weatherCurrent} weatherForecast={weatherForecast} weatherError={weatherError}
                dashboardImpact={dashboardImpact} sowingWindow={sowingWindow} activeHarvest={activeHarvest}
                onEnquiry={(buyer) => setEnquiryBuyer(buyer)} onRefresh={refreshWorkspace}
              />
            )}
            {active === "My Farm" && (
              <FarmProfile
                user={user} farm={farm} soil={soil} water={water} landSize={landSize} budget={budget}
                season={season} previousCrop={previousCrop}
                setSoil={setSoil} setWater={setWater} setLandSize={setLandSize} setBudget={setBudget}
                setSeason={setSeason} setPreviousCrop={setPreviousCrop}
                saveFarm={() => saveFarm({ land_size_acres: landSize, soil_type: soil, water_availability: water, current_season: season, budget, previous_crop: previousCrop || null })}
              />
            )}
            {active === "Crop Planner" && (
              <CropPlanner
                crops={rankedCrops} selectedCrop={selectedCrop} setSelectedCropId={setSelectedCropId}
                soil={soil} water={water} landSize={landSize} budget={budget} season={season}
                setSoil={setSoil} setWater={setWater} setLandSize={setLandSize} setBudget={setBudget} setSeason={setSeason}
                loading={plannerLoading} generatePlan={generatePlan} user={user}
              />
            )}
            {active === "Market Intelligence" && (
              <MarketView markets={marketRanking} activeHarvest={activeHarvest} cropNameById={cropNameById} go={setActive} />
            )}
            {active === "Buyers & Brokers" && (
              <BuyerView buyers={buyerMatches} activeHarvest={activeHarvest} sentBuyerIds={sentBuyerIds} onEnquiry={(buyer) => setEnquiryBuyer(buyer)} go={setActive} />
            )}
            {active === "My Harvest" && (
              <HarvestView cropCatalog={cropCatalog} harvests={harvests} cropNameById={cropNameById} recordHarvest={recordHarvest} />
            )}
            {active === "Analytics" && <Analytics dashboardImpact={dashboardImpact} marketRanking={marketRanking} farm={farm} />}
            {active === "Profile" && <UserProfile user={user} onSaved={(updated) => { setUser(updated); notify("Profile changes saved."); }} />}
          </div>
        </main>
        {toast && <div className="toast"><span>✓</span>{toast}</div>}
        {enquiryBuyer && (
          <EnquiryModal
            buyer={enquiryBuyer}
            harvest={activeHarvest}
            cropName={activeHarvest ? cropNameById(activeHarvest.crop_id) : "your crop"}
            quantity={quantity} setQuantity={setQuantity}
            sending={enquirySending}
            alreadySent={sentBuyerIds.has(enquiryBuyer.buyer_id)}
            onClose={() => setEnquiryBuyer(null)}
            onSend={submitEnquiry}
          />
        )}
      </div>
    </LanguageContext.Provider>
  );
}

function Landing({
  authMode, setAuthMode, onLogin, onSignup, onBrowse,
}: {
  authMode: "login" | "signup" | null;
  setAuthMode: (mode: "login" | "signup" | null) => void;
  onLogin: (identifier: string, password: string) => Promise<void>;
  onSignup: (payload: { name: string; phone: string; email: string; password: string; confirm_password: string; role: string; state: string; district: string }) => Promise<void>;
  onBrowse: () => void;
}) {
  const { t } = useLanguage();
  return (
    <div className="landing">
      <nav className="landing-nav">
        <div className="brand dark"><span className="brand-symbol">FW</span><span>FarmWise <b>AI</b></span></div>
        <div className="landing-links"><a href="#how">How it works</a><a href="#impact">Impact</a><a href="#trust">Trust & safety</a></div>
        <div className="landing-actions">
          <LanguageSelect />
          <button onClick={() => setAuthMode("login")}>{t("login")}</button>
          <button className="nav-cta" onClick={() => setAuthMode("signup")}>{t("signup")} <span>→</span></button>
        </div>
      </nav>
      <section className="landing-hero">
        <div className="hero-left">
          <div className="eyebrow-chip"><span>✦</span> Decision intelligence for Indian agriculture</div>
          <h1>From what to grow<br /><em>to where to sell.</em></h1>
          <p>FarmWise helps farmers make better crop and market decisions with clear, explainable intelligence built for the real Indian agricultural ecosystem.</p>
          <div className="hero-actions">
            <button className="hero-cta" onClick={() => setAuthMode("signup")}>Build my farm plan <span>→</span></button>
            <button className="demo-cta" onClick={onBrowse}><span>▷</span> Browse markets & buyers</button>
          </div>
          <div className="hero-proof">
            <div className="proof-avatars"><span>AS</span><span>RK</span><span>MN</span></div>
            <span><strong>Built for everyday decisions</strong><small>What · When · Where · Whom</small></span>
          </div>
        </div>
        <div className="hero-photo">
          <img src="https://images.unsplash.com/photo-1500937386664-56d1dfef3854?auto=format&fit=crop&w=1200&q=85" alt="Agricultural field at sunrise" />
          <div className="photo-overlay" />
          <div className="hero-photo-card"><span className="live-dot" /> <strong>Real-time decision support</strong><small>Rule-based crop scoring</small><b>Explainable, not a black box</b></div>
          <div className="photo-location">Built for Kharif & Rabi seasons</div>
        </div>
      </section>
      <section className="landing-strip">
        <span>One platform for the complete crop-to-market journey</span>
        <div><b>01</b> Grow smarter <i /> <b>02</b> Sell with clarity <i /> <b>03</b> Build resilience</div>
      </section>
      <section className="landing-how" id="how">
        <div><p className="eyebrow green">THE FARM-TO-MARKET LOOP</p><h2>Every decision is<br /><em>connected.</em></h2></div>
        <div className="how-grid">
          <InfoTile num="01" title="Know your farm" text="Translate soil, water, season and budget into a practical starting point." />
          <InfoTile num="02" title="See the trade-offs" text="Compare crops and markets on suitability, cost, risk and what you take home." />
          <InfoTile num="03" title="Act with confidence" text="Connect with real market participants already part of your local ecosystem." />
        </div>
      </section>
      <footer className="landing-footer">
        <div className="brand dark"><span className="brand-symbol">FW</span><span>FarmWise <b>AI</b></span></div>
        <span>Better decisions. Stronger harvests.</span>
        <button onClick={() => setAuthMode("login")}>Open workspace →</button>
      </footer>
      {authMode && <AuthModal mode={authMode} setMode={setAuthMode} onClose={() => setAuthMode(null)} onLogin={onLogin} onSignup={onSignup} />}
    </div>
  );
}

function PublicPreviewModal({ onClose, onSignup }: { onClose: () => void; onSignup: () => void }) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [markets, setMarkets] = useState<{ id: number; name: string; location_name: string }[]>([]);
  const [buyers, setBuyers] = useState<{ id: number; name: string; business_type: string; location_name: string; verification_status: string }[]>([]);
  useEffect(() => {
    Promise.all([api.markets(), api.buyers()])
      .then(([marketList, buyerList]) => { setMarkets(marketList.slice(0, 6)); setBuyers(buyerList.slice(0, 6)); })
      .catch(() => setError("Could not reach the FarmWise API. Start the backend or check VITE_API_URL."))
      .finally(() => setLoading(false));
  }, []);
  return (
    <div className="modal-backdrop">
      <div className="auth-modal">
        <button className="modal-close" onClick={onClose}>×</button>
        <span className="modal-kicker">LIVE DIRECTORY</span>
        <h2>Markets and buyers already on FarmWise.</h2>
        <p>A live, unauthenticated preview of the network — no sign-up required to look.</p>
        {loading && <div className="empty-state"><span className="spinner" /> Loading live data...</div>}
        {error && <div className="auth-error">{error}</div>}
        {!loading && !error && (
          <>
            <h3 style={{ margin: "14px 0 6px", fontSize: 12 }}>Markets</h3>
            {markets.map((market) => (
              <div key={market.id} className="buyer-row">
                <div className="buyer-initials">{market.name.slice(0, 2).toUpperCase()}</div>
                <div className="buyer-row-info"><div><strong>{market.name}</strong></div><small>{market.location_name}</small></div>
              </div>
            ))}
            <h3 style={{ margin: "14px 0 6px", fontSize: 12 }}>Buyers</h3>
            {buyers.map((buyer) => (
              <div key={buyer.id} className="buyer-row">
                <div className="buyer-initials">{initialsOf(buyer.name)}</div>
                <div className="buyer-row-info"><div><strong>{buyer.name}</strong><span>{buyer.verification_status === "verified" ? "✓ Verified" : "Pending verification"}</span></div><small>{buyer.business_type} · {buyer.location_name}</small></div>
              </div>
            ))}
          </>
        )}
        <button className="auth-submit" onClick={onSignup}>Create an account for personalized matching <span>→</span></button>
      </div>
    </div>
  );
}

function AuthModal({
  mode, setMode, onClose, onLogin, onSignup,
}: {
  mode: "login" | "signup";
  setMode: (mode: "login" | "signup" | null) => void;
  onClose: () => void;
  onLogin: (identifier: string, password: string) => Promise<void>;
  onSignup: (payload: { name: string; phone: string; email: string; password: string; confirm_password: string; role: string; state: string; district: string }) => Promise<void>;
}) {
  const { t } = useLanguage();
  const [name, setName] = useState("");
  const [identifier, setIdentifier] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmation, setConfirmation] = useState("");
  const [state, setState] = useState("");
  const [district, setDistrict] = useState("");
  const [role, setRole] = useState("farmer");
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const submit = async () => {
    try {
      setError(""); setSubmitting(true);
      if (mode === "login") await onLogin(identifier, password);
      else await onSignup({ name, phone, email, password, confirm_password: confirmation, role, state, district });
    } catch (submitError) { setError(submitError instanceof Error ? submitError.message : "Unable to continue"); }
    finally { setSubmitting(false); }
  };
  return (
    <div className="modal-backdrop">
      <div className="auth-modal">
        <button className="modal-close" onClick={onClose}>×</button>
        <span className="modal-kicker">FARMWISE AI</span>
        <h2>{mode === "login" ? t("login") : "Start with your farm."}</h2>
        <p>{mode === "login" ? "Continue your crop-to-market plan." : "Create a profile built around your next decision."}</p>
        {mode === "signup" && <label>FULL NAME<input value={name} onChange={(event) => setName(event.target.value)} placeholder="Your full name" /></label>}
        <label>
          {mode === "login" ? "MOBILE NUMBER OR EMAIL" : "MOBILE NUMBER"}
          <input value={mode === "login" ? identifier : phone} onChange={(event) => mode === "login" ? setIdentifier(event.target.value) : setPhone(event.target.value)} placeholder={mode === "login" ? "+91 98765 43210 or email" : "+91 98765 43210"} />
        </label>
        {mode === "signup" && <label>EMAIL<input value={email} onChange={(event) => setEmail(event.target.value)} type="email" placeholder="you@example.com" /></label>}
        <label>PASSWORD<input value={password} onChange={(event) => setPassword(event.target.value)} type="password" placeholder="••••••••" /></label>
        {mode === "signup" && (
          <>
            <label>CONFIRM PASSWORD<input value={confirmation} onChange={(event) => setConfirmation(event.target.value)} type="password" placeholder="Repeat password" /></label>
            <div className="two-fields"><label>STATE<input value={state} onChange={(event) => setState(event.target.value)} placeholder="Karnataka" /></label><label>DISTRICT<input value={district} onChange={(event) => setDistrict(event.target.value)} placeholder="Mandya" /></label></div>
            <label>ACCOUNT TYPE
              <select value={role} onChange={(event) => setRole(event.target.value)}>
                <option value="farmer">Farmer</option>
                <option value="buyer">Buyer / broker</option>
              </select>
            </label>
          </>
        )}
        {error && <div className="auth-error">{error}</div>}
        <button className="auth-submit" onClick={submit} disabled={submitting}>
          {submitting ? "Please wait..." : mode === "login" ? "Log in to workspace" : "Create my account"} <span>→</span>
        </button>
        <div className="auth-switch">
          {mode === "login" ? "New to FarmWise?" : "Already have an account?"}{" "}
          <button onClick={() => setMode(mode === "login" ? "signup" : "login")}>{mode === "login" ? "Create account" : "Log in"}</button>
        </div>
        <small className="auth-note">By continuing, you agree to use recommendations as estimates and decision support.</small>
      </div>
    </div>
  );
}

function LanguageSelect() {
  const { language, setLanguage } = useLanguage();
  return <select className="lang-button" value={language} onChange={(event) => setLanguage(event.target.value as Language)} aria-label="Language"><option value="en">EN</option><option value="kn">ಕನ್ನಡ</option><option value="te">తెలుగు</option><option value="ta">தமிழ்</option></select>;
}

function Dashboard({
  user, farm, go, rankedCrops, marketRanking, buyerMatches,
  weatherCurrent, weatherForecast, weatherError, dashboardImpact, sowingWindow, activeHarvest,
  onEnquiry, onRefresh,
}: {
  user: User | null;
  farm: Farm | null;
  go: (module: Module) => void;
  rankedCrops: DisplayCrop[];
  marketRanking: ApiMarketRank[];
  buyerMatches: ApiBuyerMatch[];
  weatherCurrent: WeatherCurrent | null;
  weatherForecast: WeatherForecastDay[];
  weatherError: boolean;
  dashboardImpact: DashboardImpact | null;
  sowingWindow: { start: string; end: string } | null;
  activeHarvest: Harvest | null;
  onEnquiry: (buyer: ApiBuyerMatch) => void;
  onRefresh: () => void;
}) {
  const { t } = useLanguage();
  const upcomingForecast = weatherForecast.slice(1, 4);
  return (
    <>
      <div className="page-intro">
        <div>
          <p className="eyebrow green">YOUR FARMWISE WORKSPACE</p>
          <h1>{t("greeting")}, {user?.name ?? "there"} <span>✦</span></h1>
          <p>{farm ? `${farm.land_size_acres} acres · ${farm.soil_type} soil · ${farm.water_availability} water` : "Complete your farm profile to unlock personal recommendations."}</p>
        </div>
        <div className="intro-actions">
          <span className="demo-badge">● LIVE ACCOUNT DATA</span>
          <button className="primary-button" onClick={() => go("My Farm")}>+ Update farm inputs</button>
        </div>
      </div>
      <section className="dashboard-hero">
        <div>
          <span className="hero-label">YOUR NEXT BEST DECISION</span>
          <h2>Net profit before<br /><em>you plant.</em></h2>
          <p>FarmWise connects your farm profile, timing, markets and buyers into one clear plan.</p>
          <button className="cream-button" onClick={() => go("Crop Planner")}>Open crop planner <span>→</span></button>
        </div>
        <div className="dashboard-hero-art">
          <div className="sun-art" /><div className="crop-row one" /><div className="crop-row two" />
          <div className="hero-seal"><strong>₹</strong><span>Make every<br />acre count</span></div>
        </div>
      </section>
      <div className="stat-row">
        <Stat label="Expected net realization" value={dashboardImpact ? `INR ${Math.round(dashboardImpact.expected_net_realization).toLocaleString("en-IN")}` : "—"} note="profile estimate" change={dashboardImpact ? "Estimated" : "Add farm"} />
        <Stat label="Top crop fit" value={rankedCrops[0]?.name ?? "—"} note={rankedCrops[0] ? `${rankedCrops[0].score}% suitability` : "No recommendation yet"} change={rankedCrops[0] ? "Top pick" : "Add farm"} />
        <Stat label="Best market" value={marketRanking[0]?.market ?? "—"} note={marketRanking[0] ? `INR ${marketRanking[0].net_realization_per_kg.toFixed(2)} / kg net` : "No harvest recorded"} change={marketRanking[0] ? "Recommended" : "Add harvest"} />
        <Stat label="Water efficiency" value={dashboardImpact ? `${dashboardImpact.water_efficiency_index}%` : "—"} note="resource estimate" change={dashboardImpact ? "On track" : "Add farm"} />
      </div>
      <div className="section-title">
        <div><span className="section-index">01</span><div><p className="eyebrow">THE FARM-TO-MARKET PLAN</p><h2>Your decision path</h2></div></div>
        <button className="link-button" onClick={onRefresh}>Refresh workspace ↻</button>
      </div>
      <div className="journey-card">
        <Journey label="Grow" value={rankedCrops[0]?.name ?? "No crop yet"} status={rankedCrops[0] ? "Recommended" : "Add farm profile"} icon="✦" active />
        <Journey label="Sow" value={sowingWindow ? `${formatDate(sowingWindow.start)}–${formatDate(sowingWindow.end)}` : "—"} status={sowingWindow ? "Suggested window" : "Pick a crop"} icon="◷" />
        <Journey label="Harvest" value={activeHarvest ? `${activeHarvest.quantity_tonnes} tonnes` : "No harvest yet"} status={activeHarvest ? `Recorded ${formatDate(activeHarvest.harvest_date)}` : "Add harvest"} icon="◒" />
        <Journey label="Sell" value={marketRanking[0]?.market ?? "No market yet"} status={marketRanking[0] ? `INR ${marketRanking[0].net_realization_per_kg.toFixed(2)} / kg` : "Add harvest"} icon="↗" />
        <Journey label="Connect" value={buyerMatches.length ? `${buyerMatches.length} buyers` : "No matches yet"} status={buyerMatches[0] ? `${buyerMatches[0].match_score}% top match` : "Add harvest"} icon="♧" />
      </div>
      <div className="section-title spaced">
        <div><span className="section-index">02</span><div><p className="eyebrow">{t("cropPlan")}</p><h2>{t("cropPlan")}</h2></div></div>
        <button className="link-button" onClick={() => go("Crop Planner")}>See full analysis →</button>
      </div>
      <div className="dashboard-grid">
        <div className="panel recommendation-panel">
          <div className="panel-head">
            <div><h3>Best fit for your {farm?.current_season ?? "current"} season</h3><p>Weighted against your soil, water, budget and nearby demand.</p></div>
            <span className="data-tag">RULE-BASED SCORE</span>
          </div>
          <div className="mini-crops">
            {rankedCrops.map((crop, i) => <MiniCrop key={crop.id} crop={crop} index={i} onClick={() => go("Crop Planner")} />)}
            {!rankedCrops.length && <p className="empty-state">Add your farm profile to generate crop recommendations.</p>}
          </div>
          <div className="why-strip">
            <span>✦</span>
            <div><strong>Why {rankedCrops[0]?.name ?? "this crop"}?</strong><p>{rankedCrops[0]?.reason ?? "Create a farm profile to generate an explainable crop recommendation."}</p></div>
            <button onClick={() => go("Crop Planner")}>Why? →</button>
          </div>
        </div>
        <div className="panel weather-panel">
          <div className="panel-head">
            <div><p className="eyebrow">TODAY IN {user?.district?.toUpperCase() ?? "YOUR AREA"}</p><h3>Monsoon watch</h3></div>
            <span className="weather-symbol">◒</span>
          </div>
          <div className="weather-main">
            <strong>{weatherCurrent?.temperature_c != null ? `${Math.round(weatherCurrent.temperature_c)}°` : "—"}</strong>
            <span>
              {weatherError ? "Weather service unavailable" : weatherCurrent?.description ?? "Loading weather..."}<br />
              <b>{weatherCurrent?.humidity_percent != null ? `${weatherCurrent.humidity_percent}% humidity` : ""}</b>
            </span>
          </div>
          <div className="weather-days">
            {upcomingForecast.length
              ? upcomingForecast.map((day) => (
                <span key={day.date}>{new Date(day.date).toLocaleDateString("en-IN", { weekday: "short" }).toUpperCase()} <b>{Math.round(day.temp_max_c)}°</b></span>
              ))
              : <span>No forecast yet</span>}
          </div>
          <div className="alert-note">
            <span>!</span> {weatherForecast[0] && weatherForecast[0].rain_probability_percent >= 40 ? `Rain probability is ${weatherForecast[0].rain_probability_percent}% today — review irrigation plans.` : weatherError ? "Connect to the FarmWise API for live alerts." : "No significant weather alerts today."}
          </div>
        </div>
      </div>
      <div className="section-title spaced">
        <div><span className="section-index">03</span><div><p className="eyebrow">{t("marketPlan")}</p><h2>{t("markets")}</h2></div></div>
        <button className="link-button" onClick={() => go("Market Intelligence")}>View all markets →</button>
      </div>
      <div className="bottom-grid">
        <div className="panel market-panel">
          <div className="market-map">
            <div className="map-grid" /><span className="map-label farmer">YOU</span>
            {marketRanking.map((market, i) => (
              <button key={market.market_id} className={`map-pin pin-${(i % 5) + 1}`} onClick={() => go("Market Intelligence")}>⌖<small>{market.market.split(" ")[0]}</small></button>
            ))}
            <div className="map-legend"><span><i className="you-dot" /> Your farm</span><span><i className="market-dot" /> Markets</span></div>
          </div>
          <div className="market-summary">
            <div>
              <span className="eyebrow">RECOMMENDED MARKET</span>
              <h3>{marketRanking[0]?.market ?? "No market selected"}</h3>
              <p>{marketRanking[0] ? "Highest net realization after transport and charges." : "Add a harvest to compare selling options."}</p>
            </div>
            <strong>{marketRanking[0] ? `INR ${marketRanking[0].net_realization_per_kg.toFixed(2)}` : "—"}<small>/ kg net</small></strong>
          </div>
        </div>
        <div className="panel buyers-preview">
          <div className="panel-head">
            <div><p className="eyebrow">WHOM TO CONTACT</p><h3>Buyer matches</h3></div>
            <span className="match-pill">{buyerMatches.length ? `${buyerMatches.length} found` : "No harvest match"}</span>
          </div>
          {buyerMatches.slice(0, 2).map((buyer) => <BuyerRow key={buyer.buyer_id} buyer={buyer} onEnquiry={() => onEnquiry(buyer)} />)}
          {!buyerMatches.length && <p className="empty-state">Record a harvest to see buyer matches for your crop.</p>}
          <button className="full-width-link" onClick={() => go("Buyers & Brokers")}>Explore buyer network →</button>
        </div>
      </div>
      <div className="impact-callout">
        <div><p className="eyebrow light">EXPECTED IMPACT</p><h2>Small choices.<br /><em>Compounding gains.</em></h2><p>{dashboardImpact?.data_label ?? "Estimates based on your farm profile."}</p></div>
        <ImpactStat value={dashboardImpact ? `INR ${Math.round(dashboardImpact.expected_farmer_profit).toLocaleString("en-IN")}` : "—"} label="Expected profit" />
        <ImpactStat value={dashboardImpact ? `${dashboardImpact.post_harvest_loss_assumption_percent}%` : "—"} label="Est. post-harvest loss" />
        <ImpactStat value={dashboardImpact ? `${dashboardImpact.water_efficiency_index}%` : "—"} label="Water efficiency" />
        <button className="cream-button" onClick={() => go("Analytics")}>Open analytics <span>→</span></button>
      </div>
      <footer className="app-footer">
        <span>FarmWise AI</span>
        <span>Decision support for better farm outcomes</span>
        <span>All values are estimates · Live account data</span>
      </footer>
    </>
  );
}

function CropPlanner({
  crops, selectedCrop, setSelectedCropId, soil, water, landSize, budget, season,
  setSoil, setWater, setLandSize, setBudget, setSeason, loading, generatePlan, user,
}: {
  crops: DisplayCrop[];
  selectedCrop: DisplayCrop | null;
  setSelectedCropId: (id: number) => void;
  soil: string; water: string; landSize: number; budget: number; season: string;
  setSoil: (value: string) => void; setWater: (value: string) => void;
  setLandSize: (value: number) => void; setBudget: (value: number) => void; setSeason: (value: string) => void;
  loading: boolean; generatePlan: () => void; user: User | null;
}) {
  return (
    <>
      <PageHeading eyebrow="CROP PLANNER" title="What should I grow?" text="Start with the conditions you can control. FarmWise will explain the trade-offs behind every recommendation." />
      <div className="planner-layout">
        <aside className="planner-form panel">
          <div className="panel-head"><div><h3>Your farm inputs</h3><p>Adjust any input to refresh your shortlist.</p></div><span className="step-pill">1 of 1</span></div>
          <label>LOCATION<div className="input-with-icon">⌖<input value={user?.district ? `${user.district}, ${user.state ?? ""}` : "Add your location in Profile"} readOnly /></div></label>
          <div className="two-fields">
            <label>LAND SIZE (ACRES)<input type="number" min={0.1} step={0.1} value={landSize} onChange={(e) => setLandSize(Number(e.target.value) || 0)} /></label>
            <label>SEASON
              <select value={season} onChange={(e) => setSeason(e.target.value)}>
                <option>Kharif</option>
                <option>Rabi</option>
                <option>Zaid</option>
              </select>
            </label>
          </div>
          <label>SOIL TYPE
            <select value={soil} onChange={(e) => setSoil(e.target.value)}>
              <option>Loamy</option><option>Red loam</option><option>Black soil</option><option>Alluvial soil</option>
            </select>
          </label>
          <label>WATER AVAILABILITY
            <select value={water} onChange={(e) => setWater(e.target.value)}>
              <option>Low</option><option>Medium</option><option>High</option>
            </select>
          </label>
          <label>AVAILABLE BUDGET (INR)<input type="number" min={0} step={500} value={budget} onChange={(e) => setBudget(Number(e.target.value) || 0)} /></label>
          <button className="primary-button full" onClick={generatePlan} disabled={loading}>
            {loading ? <><span className="spinner" /> Analyzing your farm...</> : <>Generate crop recommendations <span>→</span></>}
          </button>
          <span className="form-footnote">✦ Deterministic scoring · Explainable estimates</span>
        </aside>
        <div className="planner-results">
          <div className="results-toolbar">
            <div><span className="eyebrow green">YOUR TOP OPTIONS</span><h2>Built around your farm</h2></div>
            <span className="data-tag">LIVE MARKET DATA</span>
          </div>
          {crops.map((crop, i) => (
            <CropRecommendation key={crop.id} crop={crop} rank={i + 1} selected={selectedCrop?.id === crop.id} onSelect={() => setSelectedCropId(crop.id)} />
          ))}
          {!crops.length && <p className="empty-state">Save your farm inputs to generate crop recommendations.</p>}
          <div className="planner-insight">
            <span>✦</span>
            <div><strong>How FarmWise scores crops</strong><p>25% soil · 20% climate · 15% water · 15% season · 15% profit · 10% market stability</p></div>
          </div>
        </div>
      </div>
      {selectedCrop && (
        <section className="explain-section">
          <div>
            <p className="eyebrow green">EXPLAINABLE AI</p>
            <h2>Why FarmWise recommends<br /><em>{selectedCrop.name}.</em></h2>
            <p>{selectedCrop.reason}</p>
          </div>
          <div className="score-breakdown">
            <ScoreBar label="Soil compatibility" value={selectedCrop.reasonCodes?.soil_match ?? 0} />
            <ScoreBar label="Water fit" value={selectedCrop.reasonCodes?.water_match ?? 0} />
            <ScoreBar label="Season timing" value={selectedCrop.reasonCodes?.season_match ?? 0} />
            <ScoreBar label="Profit potential" value={selectedCrop.reasonCodes?.profit_score ?? 0} />
          </div>
          <div className="explain-list">
            {selectedCrop.reasons.map((reason) => <span key={reason}>✓ {reason}</span>)}
          </div>
        </section>
      )}
    </>
  );
}

function MarketView({
  markets, activeHarvest, cropNameById, go,
}: {
  markets: ApiMarketRank[];
  activeHarvest: Harvest | null;
  cropNameById: (id: number) => string;
  go: (module: Module) => void;
}) {
  const [selected, setSelected] = useState<ApiMarketRank | null>(markets[0] ?? null);
  useEffect(() => { setSelected(markets[0] ?? null); }, [markets]);
  return (
    <>
      <PageHeading eyebrow="MARKET INTELLIGENCE" title="Where should you sell?" text="The highest quote is not always the highest take-home value. Compare the journey, costs and demand before you choose." />
      <div className="market-workspace">
        <div className="market-controls panel">
          <div className="panel-head"><div><h3>Harvest details</h3><p>Markets are ranked for the crop and quantity you recorded.</p></div><span className="data-tag">FROM YOUR RECORD</span></div>
          {activeHarvest ? (
            <>
              <label>CROP<input value={cropNameById(activeHarvest.crop_id)} readOnly /></label>
              <div className="two-fields">
                <label>QUANTITY (TONNES)<input value={activeHarvest.quantity_tonnes} readOnly /></label>
                <label>GRADE<input value={activeHarvest.grade} readOnly /></label>
              </div>
              <label>HARVEST DATE<input value={formatDate(activeHarvest.harvest_date)} readOnly /></label>
              <button className="primary-button full" onClick={() => go("My Harvest")}>Record a different harvest →</button>
            </>
          ) : (
            <>
              <p className="empty-state">Record a harvest to compare markets for your exact crop.</p>
              <button className="primary-button full" onClick={() => go("My Harvest")}>Record a harvest →</button>
            </>
          )}
        </div>
        <div className="market-visual panel">
          <div className="market-map tall">
            <div className="map-grid" /><span className="map-label farmer">YOUR FARM</span>
            {markets.map((market, i) => (
              <button key={market.market_id} className={`map-pin pin-${(i % 5) + 1} ${selected?.market_id === market.market_id ? "selected" : ""}`} onClick={() => setSelected(market)}>⌖<small>{market.market.split(" ")[0]}</small></button>
            ))}
            <div className="route-line" />
          </div>
          <div className="map-footer"><span><i className="you-dot" /> Your location</span><span><i className="market-dot" /> APMC / mandi</span></div>
        </div>
      </div>
      <div className="market-heading">
        <div><p className="eyebrow green">RANKED BY NET REALIZATION</p><h2>Nearby markets</h2></div>
        <span>{markets.length} markets compared</span>
      </div>
      <div className="market-cards">
        {markets.map((market, i) => (
          <button className={selected?.market_id === market.market_id ? "market-card chosen" : "market-card"} key={market.market_id} onClick={() => setSelected(market)}>
            <div className="market-rank">0{i + 1}</div>
            <div className="market-card-main">
              <span className="eyebrow">Mandi / market</span>
              <h3>{market.market}</h3>
              <p>{market.distance_km.toFixed(1)} km · {market.demand} buyer demand</p>
              <div className="market-card-tags"><span>Est. INR {market.market_charges_per_kg.toFixed(2)} charges/kg</span></div>
            </div>
            <div className="market-card-values">
              <small>QUOTE</small><strong>INR {market.price_per_kg.toFixed(2)}<i>/kg</i></strong>
              <small>NET REALIZATION</small><b>INR {market.net_realization_per_kg.toFixed(2)}<i>/kg</i></b>
            </div>
            {market.recommended && <span className="recommended-label">Recommended</span>}
          </button>
        ))}
        {!markets.length && <p className="empty-state">No market data yet — record a harvest to see ranked selling options.</p>}
      </div>
      <div className="tradeoff-banner">
        <span>↗</span>
        <div>
          <strong>Smart trade-off</strong>
          <p>{selected ? <>{selected.market} leaves you with <b>INR {selected.net_realization_per_kg.toFixed(2)} / kg</b> after estimated transport and market charges. FarmWise ranks what you take home, not just the quote.</> : "Add a harvest to compare markets using your crop, quantity and grade."}</p>
        </div>
      </div>
    </>
  );
}

function BuyerView({
  buyers, activeHarvest, sentBuyerIds, onEnquiry, go,
}: {
  buyers: ApiBuyerMatch[];
  activeHarvest: Harvest | null;
  sentBuyerIds: Set<number>;
  onEnquiry: (buyer: ApiBuyerMatch) => void;
  go: (module: Module) => void;
}) {
  const [filter, setFilter] = useState<string>("All buyers");
  const businessTypes = useMemo(() => ["All buyers", ...Array.from(new Set(buyers.map((b) => b.business_type)))], [buyers]);
  const filtered = filter === "All buyers" ? buyers : buyers.filter((b) => b.business_type === filter);
  return (
    <>
      <PageHeading
        eyebrow="BUYERS & BROKERS"
        title="Who should I contact?"
        text="Discover traders, commission agents, processors, FPOs and aggregators already looking for crops like yours."
        action={activeHarvest ? undefined : <button className="primary-button" onClick={() => go("My Harvest")}>+ Record a harvest</button>}
      />
      <div className="buyer-filters">
        {businessTypes.map((type) => <button key={type} className={filter === type ? "filter-active" : undefined} onClick={() => setFilter(type)}>{type}</button>)}
        <span>{filtered.length} match{filtered.length === 1 ? "" : "es"}</span>
      </div>
      <div className="buyer-list">
        {filtered.map((buyer) => (
          <BuyerLarge key={buyer.buyer_id} buyer={buyer} onEnquiry={() => onEnquiry(buyer)} sent={sentBuyerIds.has(buyer.buyer_id)} />
        ))}
        {!buyers.length && <p className="empty-state">{activeHarvest ? "No buyers currently list requirements for this crop." : "Record a harvest to receive buyer matches from the backend."}</p>}
      </div>
    </>
  );
}

function FarmProfile({
  user, farm, soil, water, landSize, budget, season, previousCrop,
  setSoil, setWater, setLandSize, setBudget, setSeason, setPreviousCrop, saveFarm,
}: {
  user: User | null;
  farm: Farm | null;
  soil: string; water: string; landSize: number; budget: number; season: string; previousCrop: string;
  setSoil: (value: string) => void; setWater: (value: string) => void;
  setLandSize: (value: number) => void; setBudget: (value: number) => void;
  setSeason: (value: string) => void; setPreviousCrop: (value: string) => void;
  saveFarm: () => Promise<void>;
}) {
  const [saving, setSaving] = useState(false);
  const filled = [user?.state, user?.district, landSize > 0, budget > 0, soil, water, season].filter(Boolean).length;
  const completion = Math.round((filled / 7) * 100);
  const submit = async () => { setSaving(true); try { await saveFarm(); } finally { setSaving(false); } };
  return (
    <>
      <PageHeading
        eyebrow="MY FARM"
        title="A profile that learns with you."
        text="Keep your farm inputs current so every recommendation stays grounded in your reality."
        action={<button className="primary-button" onClick={submit} disabled={saving}>{saving ? "Saving..." : "Save changes"}</button>}
      />
      <div className="profile-layout">
        <div className="profile-main panel">
          <div className="profile-cover">
            <div className="farm-cover-image" />
            <div className="farm-identity">
              <div className="large-avatar">{user?.name?.slice(0, 2).toUpperCase()}</div>
              <div><h2>{user?.name ?? "Your"}&apos;s farm</h2><p>{user?.district ?? user?.location_name ?? "Add your location"} · {farm?.land_size_acres ?? landSize} acres</p></div>
              <span className="complete-badge">{completion}% complete</span>
            </div>
          </div>
          <div className="profile-form">
            <h3>Farm conditions</h3>
            <div className="form-grid">
              <label>STATE<input value={user?.state ?? ""} placeholder="Add in Profile tab" readOnly /></label>
              <label>DISTRICT<input value={user?.district ?? ""} placeholder="Add in Profile tab" readOnly /></label>
              <label>LAND SIZE (ACRES)<input type="number" min={0.1} step={0.1} value={landSize} onChange={(e) => setLandSize(Number(e.target.value) || 0)} /></label>
              <label>SOIL TYPE
                <select value={soil} onChange={(e) => setSoil(e.target.value)}><option>Loamy</option><option>Red loam</option><option>Black soil</option></select>
              </label>
              <label>WATER AVAILABILITY
                <select value={water} onChange={(e) => setWater(e.target.value)}><option>Low</option><option>Medium</option><option>High</option></select>
              </label>
              <label>PREVIOUS CROP<input value={previousCrop} onChange={(e) => setPreviousCrop(e.target.value)} placeholder="e.g. Maize" /></label>
              <label>AVAILABLE BUDGET (INR)<input type="number" min={0} step={500} value={budget} onChange={(e) => setBudget(Number(e.target.value) || 0)} /></label>
              <label>CURRENT SEASON
                <select value={season} onChange={(e) => setSeason(e.target.value)}><option>Kharif</option><option>Rabi</option><option>Zaid</option></select>
              </label>
            </div>
            <div className="profile-callout">
              <span>✦</span>
              <div><strong>Every field here feeds live recommendations</strong><p>Saving updates your crop scores, sowing windows and analytics immediately.</p></div>
            </div>
          </div>
        </div>
        <aside className="profile-side">
          <div className="panel completion-card">
            <span className="ring">{completion}<small>%</small></span>
            <h3>Your farm profile</h3>
            <p>Complete profiles unlock more useful comparisons.</p>
            <div className="completion-line"><i style={{ width: `${completion}%` }} /></div>
            <small>{filled} of 7 details added</small>
          </div>
          <div className="panel location-card">
            <p className="eyebrow">FARM LOCATION</p>
            <div className="mini-map"><span>⌖</span></div>
            <strong>{user?.district && user?.state ? `${user.district}, ${user.state}` : "Add your location"}</strong>
            <small>Set from your Profile tab</small>
          </div>
        </aside>
      </div>
    </>
  );
}

function HarvestView({
  cropCatalog, harvests, cropNameById, recordHarvest,
}: {
  cropCatalog: CropCatalogItem[];
  harvests: Harvest[];
  cropNameById: (id: number) => string;
  recordHarvest: (payload: { crop_id: number; quantity_tonnes: number; grade: string; harvest_date: string }) => Promise<void>;
}) {
  const [cropId, setCropId] = useState<number | null>(cropCatalog[0]?.id ?? null);
  const [quantity, setQuantity] = useState("2");
  const [grade, setGrade] = useState("A");
  const [harvestDate, setHarvestDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [saving, setSaving] = useState(false);
  useEffect(() => { if (cropId == null && cropCatalog[0]) setCropId(cropCatalog[0].id); }, [cropCatalog, cropId]);
  const selectedCatalogCrop = cropCatalog.find((c) => c.id === cropId);
  const submit = async () => {
    if (!cropId) return;
    setSaving(true);
    try { await recordHarvest({ crop_id: cropId, quantity_tonnes: Number(quantity) || 0, grade, harvest_date: harvestDate }); }
    finally { setSaving(false); }
  };
  return (
    <>
      <PageHeading
        eyebrow="MY HARVEST"
        title="Turn harvest into a selling plan."
        text="Record what is ready, then compare markets and connect with relevant buyers."
        action={<button className="primary-button" onClick={submit} disabled={saving || !cropId}>{saving ? "Saving..." : "Save harvest"}</button>}
      />
      <div className="harvest-layout">
        <div className="harvest-form panel">
          <div className="harvest-image">
            <img src="https://images.unsplash.com/photo-1592924357228-91a4daadcfea?auto=format&fit=crop&w=1000&q=80" alt="Freshly harvested crop" />
            <div><span>HARVEST PREVIEW</span><strong>{selectedCatalogCrop ? `~${selectedCatalogCrop.duration_days}-day crop` : "Choose a crop"}</strong></div>
          </div>
          <div className="harvest-fields">
            <label>CROP
              <select value={cropId ?? ""} onChange={(e) => setCropId(Number(e.target.value))}>
                {cropCatalog.map((crop) => <option key={crop.id} value={crop.id}>{crop.name}</option>)}
              </select>
            </label>
            <label>QUANTITY (TONNES)<input type="number" min={0.1} step={0.1} value={quantity} onChange={(e) => setQuantity(e.target.value)} /></label>
            <label>QUALITY / GRADE
              <select value={grade} onChange={(e) => setGrade(e.target.value)}><option value="A">Grade A</option><option value="B">Grade B</option></select>
            </label>
            <label>HARVEST DATE<input type="date" value={harvestDate} onChange={(e) => setHarvestDate(e.target.value)} /></label>
            <button className="primary-button full" onClick={submit} disabled={saving || !cropId}>{saving ? "Saving..." : <>Find selling options →</>}</button>
          </div>
        </div>
        <div className="harvest-next">
          <span className="eyebrow green">YOUR RECORDED HARVESTS</span>
          <h2>Every harvest you save becomes real, queryable data.</h2>
          {harvests.length ? (
            <div className="next-list">
              {[...harvests].reverse().map((h) => (
                <span key={h.id}><b>{cropNameById(h.crop_id)}</b> {h.quantity_tonnes} t · Grade {h.grade} · {formatDate(h.harvest_date)}</span>
              ))}
            </div>
          ) : (
            <p className="empty-state">No harvests recorded yet. Save one above to unlock market and buyer matching.</p>
          )}
        </div>
      </div>
    </>
  );
}

function UserProfile({ user, onSaved }: { user: User | null; onSaved: (user: User) => void }) {
  const [name, setName] = useState(user?.name ?? "");
  const [state, setState] = useState(user?.state ?? "");
  const [district, setDistrict] = useState(user?.district ?? "");
  const [coords, setCoords] = useState<{ lat: number; lon: number } | null>(null);
  const [locating, setLocating] = useState(false);
  const [saving, setSaving] = useState(false);
  const useCurrentLocation = () => {
    if (!navigator.geolocation) return;
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (position) => { setCoords({ lat: position.coords.latitude, lon: position.coords.longitude }); setLocating(false); },
      () => setLocating(false),
      { enableHighAccuracy: false, timeout: 8000 },
    );
  };
  const save = async () => {
    const token = getToken();
    if (!token) return;
    setSaving(true);
    try {
      onSaved(await api.updateProfile({ name, language: user?.language ?? "en", location_name: district, state, district, latitude: coords?.lat, longitude: coords?.lon }, token));
    } finally { setSaving(false); }
  };
  return (
    <>
      <PageHeading eyebrow="PROFILE" title="Your FarmWise identity." text="Keep your personal details current. They belong only to your authenticated account." action={<button className="primary-button" onClick={save} disabled={saving}>{saving ? "Saving..." : "Save changes"}</button>} />
      <div className="profile-layout">
        <div className="profile-main panel">
          <div className="profile-form">
            <div className="farm-identity">
              <div className="large-avatar">{user?.name?.slice(0, 2).toUpperCase()}</div>
              <div><h2>{user?.name}</h2><p>{user?.role === "buyer" ? "Buyer / broker account" : "Farmer account"}</p></div>
            </div>
            <div className="form-grid">
              <label>FULL NAME<input value={name} onChange={(event) => setName(event.target.value)} /></label>
              <label>EMAIL<input value={user?.email ?? ""} readOnly /></label>
              <label>MOBILE NUMBER<input value={user?.phone ?? ""} readOnly /></label>
              <label>STATE<input value={state} onChange={(event) => setState(event.target.value)} /></label>
              <label>DISTRICT<input value={district} onChange={(event) => setDistrict(event.target.value)} /></label>
              <label>ACCOUNT TYPE<input value={user?.role ?? "farmer"} readOnly /></label>
            </div>
            <div className="profile-callout">
              <span>⌖</span>
              <div>
                <strong>{coords ? `Location captured: ${coords.lat.toFixed(3)}, ${coords.lon.toFixed(3)}` : "Share your location for accurate weather"}</strong>
                <p>Used only for weather forecasts and distance-to-market estimates.</p>
              </div>
              <button onClick={useCurrentLocation} disabled={locating}>{locating ? "Locating..." : "Use current location →"}</button>
            </div>
            <div className="profile-callout">
              <span>✓</span>
              <div><strong>Your account is protected</strong><p>Authenticated FarmWise data is scoped to your account and is never loaded from a client-supplied user ID.</p></div>
            </div>
          </div>
        </div>
        <aside className="profile-side">
          <div className="panel completion-card">
            <span className="ring">✓</span>
            <h3>Member since</h3>
            <p>{user?.created_at ? new Date(user.created_at).toLocaleDateString("en-IN", { year: "numeric", month: "long" }) : "Recently"}</p>
            <small>Role: {user?.role ?? "farmer"}</small>
          </div>
        </aside>
      </div>
    </>
  );
}

function Analytics({ dashboardImpact, marketRanking, farm }: { dashboardImpact: DashboardImpact | null; marketRanking: ApiMarketRank[]; farm: Farm | null }) {
  if (!dashboardImpact)
    return <><PageHeading eyebrow="ANALYTICS" title="Your analytics will grow with your data." text="Record a farm and harvest to calculate account-specific realization, profit and resource efficiency." /><div className="panel empty-state">No analytics are available yet for this account.</div></>;

  const top = marketRanking[0];
  const bars = top
    ? [
      { label: "Quote", value: top.price_per_kg },
      { label: "Transport", value: top.transport_cost_per_kg },
      { label: "Charges", value: top.market_charges_per_kg },
      { label: "Net realization", value: top.net_realization_per_kg },
    ]
    : [];
  const maxBar = Math.max(...bars.map((b) => b.value), 1);
  const transportEfficiency = top ? Math.max(0, Math.round((1 - top.transport_cost_per_kg / Math.max(top.price_per_kg, 1)) * 100)) : 0;
  const marketOptionality = Math.min(100, marketRanking.length * 12);

  return (
    <>
      <PageHeading eyebrow="ANALYTICS" title="See the value of each decision." text="A transparent view of estimated costs, realization and resource efficiency. Nothing here is a guarantee." />
      <div className="analytics-stats">
        <Stat label="Expected net realization" value={`INR ${Math.round(dashboardImpact.expected_net_realization).toLocaleString("en-IN")}`} note={`for ${dashboardImpact.farm_acres} acres`} change="Estimated" />
        <Stat label="Expected profit" value={`INR ${Math.round(dashboardImpact.expected_farmer_profit).toLocaleString("en-IN")}`} note="account estimate" change={`${dashboardImpact.harvest_count} harvest${dashboardImpact.harvest_count === 1 ? "" : "s"}`} />
        <Stat label="Net realization" value={top ? `INR ${top.net_realization_per_kg.toFixed(2)}` : "—"} note="per kg, best market" change={top ? "Best option" : "Add harvest"} />
        <Stat label="Sustainability score" value={`${dashboardImpact.water_efficiency_index} / 100`} note="water efficiency index" change="On track" />
      </div>
      <div className="analytics-grid">
        <div className="panel chart-panel">
          <div className="panel-head"><div><p className="eyebrow">PRICE BREAKDOWN</p><h3>Your best market, per kg</h3></div><span className="data-tag">{top ? top.market.toUpperCase() : "NO DATA"}</span></div>
          {bars.length ? (
            <div className="bar-chart">
              <div className="axis"><span>INR {maxBar.toFixed(0)}</span><span>{(maxBar * 0.5).toFixed(0)}</span><span>0</span></div>
              <div className="bars">
                {bars.map((bar, i) => (
                  <div className="bar-set" key={bar.label}>
                    <div className={`bar bar-${i}`} style={{ height: `${Math.max(4, (bar.value / maxBar) * 100)}%` }} />
                    <small>{bar.label}</small>
                  </div>
                ))}
              </div>
            </div>
          ) : <p className="empty-state">Record a harvest to see a real price breakdown for your top market.</p>}
        </div>
        <div className="panel efficiency-panel">
          <div className="panel-head"><div><p className="eyebrow">RESOURCE EFFICIENCY</p><h3>A lighter plan</h3></div></div>
          <ScoreBar label="Water efficiency" value={dashboardImpact.water_efficiency_index} />
          <ScoreBar label="Input efficiency" value={dashboardImpact.input_efficiency_index} />
          <ScoreBar label="Transport efficiency" value={transportEfficiency} />
          <ScoreBar label="Market optionality" value={marketOptionality} />
          <div className="efficiency-note">
            {farm ? `Based on your ${farm.soil_type.toLowerCase()} soil and ${farm.water_availability.toLowerCase()} water availability.` : "Complete your farm profile for a more precise efficiency estimate."}
          </div>
        </div>
      </div>
    </>
  );
}

function PageHeading({ eyebrow, title, text, action }: { eyebrow: string; title: string; text: string; action?: React.ReactNode }) {
  return <div className="page-heading"><div><p className="eyebrow green">{eyebrow}</p><h1>{title}</h1><p>{text}</p></div>{action}</div>;
}
function InfoTile({ num, title, text }: { num: string; title: string; text: string }) {
  return <div className="info-tile"><span>{num}</span><h3>{title}</h3><p>{text}</p></div>;
}
function Stat({ label, value, note, change }: { label: string; value: string; note: string; change: string }) {
  return <div className="stat-card"><span>{label}</span><strong>{value}</strong><div><small>{note}</small><em>{change}</em></div></div>;
}
function ImpactStat({ value, label }: { value: string; label: string }) {
  return <div className="impact-stat"><strong>{value}</strong><span>{label}</span></div>;
}
function Journey({ label, value, status, icon, active }: { label: string; value: string; status: string; icon: string; active?: boolean }) {
  return <div className={active ? "journey active" : "journey"}><span>{icon}</span><small>{label}</small><strong>{value}</strong><em>{status}</em></div>;
}
function MiniCrop({ crop, index, onClick }: { crop: DisplayCrop; index: number; onClick: () => void }) {
  return (
    <button className={index === 0 ? "mini-crop selected" : "mini-crop"} onClick={onClick}>
      <img src={crop.image} alt="" />
      <div>
        <strong>{crop.name}</strong>
        <small>{crop.water} water · {crop.risk} risk</small>
        <div className="mini-score"><i style={{ width: `${crop.score}%` }} /><b>{crop.score}%</b></div>
      </div>
      <span>{crop.profit}<small>/ acre est.</small></span>
      <b className="mini-rank">0{index + 1}</b>
    </button>
  );
}
function CropRecommendation({ crop, rank, selected, onSelect }: { crop: DisplayCrop; rank: number; selected: boolean; onSelect: () => void }) {
  return (
    <button className={selected ? "crop-recommendation selected" : "crop-recommendation"} onClick={onSelect}>
      <img src={crop.image} alt={`${crop.name} crop`} />
      <div className="crop-rec-content">
        <div className="crop-rec-top">
          <div><span className="rec-rank">0{rank}</span><h3>{crop.name}</h3><p>{crop.risk} market risk · {crop.water} water</p></div>
          <div className="suitability"><strong>{crop.score}%</strong><span>farm suitability</span></div>
        </div>
        <div className="rec-details">
          <span><small>EXPECTED YIELD</small><b>{crop.yieldLabel}</b></span>
          <span><small>EST. COST</small><b>{crop.costLabel} / acre</b></span>
          <span><small>EST. RETURN</small><b>{crop.profit} / acre</b></span>
        </div>
        <div className="rec-reason">
          <span>✦</span><p>{crop.reason}</p>
          <b>{selected ? "Selected" : "View recommendation"} {selected ? "✓" : "→"}</b>
        </div>
      </div>
    </button>
  );
}
function ScoreBar({ label, value }: { label: string; value: number }) {
  return <div className="score-bar"><div><span>{label}</span><b>{value}</b></div><i><em style={{ width: `${value}%` }} /></i></div>;
}
function BuyerRow({ buyer, onEnquiry }: { buyer: ApiBuyerMatch; onEnquiry: () => void }) {
  return (
    <div className="buyer-row">
      <div className="buyer-initials">{initialsOf(buyer.name)}</div>
      <div className="buyer-row-info">
        <div><strong>{buyer.name}</strong><span>{buyer.verification_status === "verified" ? "✓ Verified fields" : "Pending verification"}</span></div>
        <small>{buyer.location_name} · {buyer.required_quantity}</small>
      </div>
      <div className="match-score"><strong>{buyer.match_score}%</strong><small>match</small></div>
      <button onClick={onEnquiry}>Enquire</button>
    </div>
  );
}
function BuyerLarge({ buyer, onEnquiry, sent }: { buyer: ApiBuyerMatch; onEnquiry: () => void; sent: boolean }) {
  return (
    <div className="buyer-large panel">
      <div className="buyer-big-avatar">{initialsOf(buyer.name)}</div>
      <div className="buyer-large-info">
        <div className="buyer-name-line"><h3>{buyer.name}</h3>{buyer.verification_status === "verified" && <span className="verified-pill">✓ Verified fields</span>}</div>
        <p>{buyer.business_type} · {buyer.location_name}</p>
        <div className="buyer-facts">
          <span><small>REQUIRED QUANTITY</small><b>{buyer.required_quantity}</b></span>
          <span><small>EXPECTED OFFER</small><b>INR {buyer.offer_price_range}</b></span>
          <span><small>VERIFIED DATA</small><b>{buyer.verification_fields.length ? buyer.verification_fields.join(" · ") : "Not yet verified"}</b></span>
          <span><small>RATING</small><b>{buyer.rating ? buyer.rating.toFixed(1) : "New"}</b></span>
        </div>
      </div>
      <div className="buyer-match-ring"><strong>{buyer.match_score}%</strong><span>AI match</span></div>
      <div className="buyer-actions">
        <button className="primary-button" onClick={onEnquiry}>{sent ? "Enquiry sent ✓" : "Contact buyer"}</button>
      </div>
    </div>
  );
}
function EnquiryModal({
  buyer, harvest, cropName, quantity, setQuantity, sending, alreadySent, onClose, onSend,
}: {
  buyer: ApiBuyerMatch;
  harvest: Harvest | null;
  cropName: string;
  quantity: string;
  setQuantity: (value: string) => void;
  sending: boolean;
  alreadySent: boolean;
  onClose: () => void;
  onSend: (message: string, offeredPrice: number, quantityTonnes: number) => Promise<void>;
}) {
  const midpointPrice = useMemo(() => {
    const [low, high] = buyer.offer_price_range.split("-").map((v) => parseFloat(v));
    if (Number.isFinite(low) && Number.isFinite(high)) return Math.round(((low + high) / 2) * 100) / 100;
    return 0;
  }, [buyer.offer_price_range]);
  const [price, setPrice] = useState(midpointPrice);
  const [message, setMessage] = useState(`I have ${harvest?.quantity_tonnes ?? quantity} tonnes of Grade ${harvest?.grade ?? "A"} ${cropName} available for sale.`);
  const disabled = sending || alreadySent || !harvest;
  return (
    <div className="modal-backdrop">
      <div className="enquiry-modal">
        <button className="modal-close" onClick={onClose}>×</button>
        <span className="modal-kicker">NEW ENQUIRY</span>
        <h2>Connect with {buyer.name}.</h2>
        <p>Send a clear request so the buyer can respond faster.</p>
        <div className="enquiry-buyer">
          <div className="buyer-initials">{initialsOf(buyer.name)}</div>
          <div><strong>{buyer.name}</strong><small>{buyer.business_type} · {buyer.location_name} · {buyer.match_score}% match</small></div>
        </div>
        {!harvest && <div className="auth-error">Record a harvest first so FarmWise knows what you are selling.</div>}
        <div className="two-fields">
          <label>CROP<input value={cropName} readOnly /></label>
          <label>QUANTITY (TONNES)<input value={quantity} onChange={(e) => setQuantity(e.target.value.replace(/[^0-9.]/g, ""))} /></label>
        </div>
        <div className="two-fields">
          <label>GRADE<input value={harvest?.grade ?? "A"} readOnly /></label>
          <label>OFFERED PRICE (INR/KG)<input type="number" step={0.5} value={price} onChange={(e) => setPrice(Number(e.target.value) || 0)} /></label>
        </div>
        <label>MESSAGE<textarea value={message} onChange={(e) => setMessage(e.target.value)} /></label>
        <button className="auth-submit" onClick={() => onSend(message, price, Number(quantity) || 0)} disabled={disabled}>
          {alreadySent ? "Enquiry already sent ✓" : sending ? "Sending..." : "Send enquiry"} <span>→</span>
        </button>
        <small className="modal-disclaimer">Verified fields are shown exactly as provided by the buyer. FarmWise does not guarantee transactions.</small>
      </div>
    </div>
  );
}

export default App;
