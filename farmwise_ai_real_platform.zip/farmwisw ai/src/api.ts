const API_BASE = import.meta.env.VITE_API_URL ?? "http://127.0.0.1:8000/api/v1";

export type User = {
  id: number;
  name: string;
  phone: string;
  email?: string | null;
  role: string;
  language?: string;
  location_name?: string | null;
  state?: string | null;
  district?: string | null;
  created_at?: string | null;
};

export type Farm = {
  id: number;
  land_size_acres: number;
  soil_type: string;
  water_availability: string;
  current_season: string;
  budget: number;
  previous_crop?: string | null;
};

export type ApiCrop = {
  crop_id: number;
  crop: string;
  score: number;
  risk: string;
  expected_profit_per_acre: number;
  reasons: string[];
  explanation: string;
  reason_codes?: {
    soil_match: number;
    climate_match: number;
    water_match: number;
    season_match: number;
    profit_score: number;
    market_stability: number;
  };
};

export type CropCatalogItem = {
  id: number;
  name: string;
  duration_days: number;
  water_requirement: string;
  risk_level: string;
  expected_yield_per_acre: number;
  base_production_cost_per_acre: number;
};

export type Harvest = {
  id: number;
  crop_id: number;
  quantity_tonnes: number;
  grade: string;
  harvest_date: string;
  notes?: string | null;
};

export type ApiMarketRank = {
  market_id: number;
  market: string;
  price_per_kg: number;
  distance_km: number;
  transport_cost_per_kg: number;
  market_charges_per_kg: number;
  net_realization_per_kg: number;
  score: number;
  demand: string;
  reasons: string[];
  recommended: boolean;
};

export type ApiBuyerMatch = {
  buyer_id: number;
  name: string;
  business_type: string;
  location_name: string;
  rating: number;
  verification_status: string;
  verification_fields: string[];
  match_score: number;
  required_quantity: string;
  offer_price_range: string;
  reasons: string[];
};

export type ApiBuyer = {
  id: number;
  name: string;
  business_type: string;
  location_name: string;
  verification_status: string;
  verification_fields?: string;
  rating?: number;
};

export type ApiMarket = {
  id: number;
  name: string;
  location_name: string;
  active?: boolean;
};

export type Enquiry = {
  id: number;
  buyer_id: number;
  harvest_id: number;
  quantity_tonnes: number;
  offered_price: number;
  status: string;
  created_at?: string;
};

export type WeatherCurrent = {
  temperature_c: number | null;
  humidity_percent: number | null;
  precipitation_mm: number | null;
  wind_speed_kmh: number | null;
  weather_code: number | null;
  description: string;
  provider: string;
};

export type WeatherForecastDay = {
  date: string;
  temp_max_c: number;
  temp_min_c: number;
  precipitation_mm: number;
  rain_probability_percent: number;
  weather_code: number;
  description: string;
};

export type DashboardImpact = {
  farm_acres: number;
  expected_net_realization: number;
  expected_farmer_profit: number;
  transport_cost_per_kg: number;
  estimated_selling_delay_days: number;
  post_harvest_loss_assumption_percent: number;
  water_efficiency_index: number;
  input_efficiency_index: number;
  harvest_count: number;
  enquiry_count: number;
  completed_deals: number;
  top_crop_score: number | null;
  data_label: string;
};

export class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

async function request<T>(
  path: string,
  options: RequestInit = {},
  token?: string,
): Promise<T> {
  let response: Response;
  try {
    response = await fetch(`${API_BASE}${path}`, {
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
        ...(options.headers ?? {}),
      },
    });
  } catch {
    throw new Error("FarmWise API is not reachable. Start the backend locally or configure VITE_API_URL for the deployed app.");
  }
  const body = await response.json().catch(() => ({}));
  if (!response.ok)
    throw new ApiError(
      body?.detail?.message ??
        body?.detail ??
        body?.message ??
        "Request failed",
      response.status,
    );
  return body.data ?? body;
}

export const api = {
  login: (identifier: string, password: string) =>
    request<{ access_token: string; user: User }>("/auth/login", {
      method: "POST",
      body: JSON.stringify({ identifier, password }),
    }),
  register: (payload: {
    name: string;
    phone: string;
    email: string;
    password: string;
    confirm_password: string;
    role: string;
    state: string;
    district: string;
  }) =>
    request<{ access_token: string; user: User }>("/auth/register", {
      method: "POST",
      body: JSON.stringify(payload),
    }),
  me: (token: string) => request<User>("/auth/me", {}, token),
  updateProfile: (
    payload: {
      name: string;
      language: string;
      location_name?: string | null;
      state?: string | null;
      district?: string | null;
      latitude?: number | null;
      longitude?: number | null;
    },
    token: string,
  ) => request<User>("/auth/profile", { method: "PUT", body: JSON.stringify(payload) }, token),

  farms: (token: string) => request<Farm[]>("/farms", {}, token),
  createFarm: (payload: Omit<Farm, "id">, token: string) => request<Farm>("/farms", { method: "POST", body: JSON.stringify(payload) }, token),
  updateFarm: (id: number, payload: Omit<Farm, "id">, token: string) => request<Farm>(`/farms/${id}`, { method: "PUT", body: JSON.stringify(payload) }, token),

  cropCatalog: () => request<CropCatalogItem[]>("/crops"),
  recommendations: (farmId: number, token: string) =>
    request<{ recommendations: ApiCrop[]; model_version: string }>(
      `/recommendations/crops`,
      { method: "POST", body: JSON.stringify({ farm_id: farmId }) },
      token,
    ),

  sowingWindow: (cropId: number, season: string, token: string) =>
    request<{
      crop: string;
      sowing_window: { start: string; end: string };
      expected_harvest_window: { start: string; end: string };
      confidence: number;
      reasons: string[];
    }>(`/recommendations/sowing-window/${cropId}?season=${encodeURIComponent(season)}`, {}, token),

  harvests: (token: string) => request<Harvest[]>("/harvests", {}, token),
  createHarvest: (
    payload: { crop_id: number; quantity_tonnes: number; grade: string; harvest_date: string; notes?: string | null },
    token: string,
  ) => request<Harvest>("/harvests", { method: "POST", body: JSON.stringify(payload) }, token),

  markets: () => request<ApiMarket[]>("/markets"),
  recommendMarkets: (harvestId: number, token: string) =>
    request<{ markets: ApiMarketRank[] }>(
      "/markets/recommend",
      { method: "POST", body: JSON.stringify({ harvest_id: harvestId }) },
      token,
    ),

  buyers: () => request<ApiBuyer[]>("/buyers"),
  matchBuyers: (harvestId: number, token: string) =>
    request<{ buyers: ApiBuyerMatch[] }>(
      "/buyers/match",
      { method: "POST", body: JSON.stringify({ harvest_id: harvestId }) },
      token,
    ),

  sendEnquiry: (
    payload: { buyer_id: number; harvest_id: number; quantity_tonnes: number; offered_price: number; message?: string },
    token: string,
  ) => request<Enquiry>("/enquiries", { method: "POST", body: JSON.stringify(payload) }, token),
  enquiries: (token: string) => request<Enquiry[]>("/enquiries", {}, token),

  weatherCurrent: (token: string) => request<WeatherCurrent>("/weather/current", {}, token),
  weatherForecast: (token: string) => request<{ forecast: WeatherForecastDay[]; provider: string }>("/weather/forecast", {}, token),

  dashboardImpact: (token: string) => request<DashboardImpact>("/dashboard/impact", {}, token),
};

export function saveToken(token: string) {
  localStorage.setItem("farmwise_access_token", token);
}
export function getToken() {
  return localStorage.getItem("farmwise_access_token");
}
export function clearToken() {
  localStorage.removeItem("farmwise_access_token");
}
