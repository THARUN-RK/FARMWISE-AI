"""Production AI advisor endpoint using a configurable OpenAI-compatible provider."""
import logging
import time
from collections import defaultdict, deque

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from app.api.deps import current_user
from app.core.config import settings
from app.core.http_client import get_http_client

log = logging.getLogger("farmwise.ai")
router = APIRouter(prefix="/ai", tags=["ai"])

_request_times: dict[int, deque[float]] = defaultdict(deque)
RATE_WINDOW = 60
RATE_LIMIT = 12

class ChatRequest(BaseModel):
    message: str = Field(min_length=2, max_length=4000)


def _allow(user_id: int) -> bool:
    now = time.time(); q = _request_times[user_id]
    while q and now - q[0] > RATE_WINDOW: q.popleft()
    if len(q) >= RATE_LIMIT: return False
    q.append(now); return True

@router.post("/chat")
async def chat(body: ChatRequest, user=Depends(current_user)):
    if not _allow(user.id):
        raise HTTPException(429, "AI request limit reached. Please wait a minute and try again.")
    if not settings.ai_api_key:
        raise HTTPException(503, "AI assistant is not configured on the server.")

    client = await get_http_client()
    payload = {
        "model": settings.ai_model,
        "messages": [
            {"role": "system", "content": (
                "You are FarmWise AI, an agricultural decision-support assistant for India. "
                "Give practical, concise and cautious guidance. Ask for missing crop/location/soil context "
                "when needed. Never invent live prices, weather, disease certainty, or government schemes. "
                "Do not claim to replace an agronomist. Clearly label uncertainty."
            )},
            {"role": "user", "content": body.message},
        ],
        "temperature": 0.2,
        "max_tokens": 900,
    }
    try:
        response = await client.post(
            f"{settings.ai_base_url.rstrip('/')}/chat/completions",
            headers={"Authorization": f"Bearer {settings.ai_api_key}"},
            json=payload,
        )
        response.raise_for_status()
        data = response.json()
    except Exception as exc:
        if isinstance(exc, HTTPException): raise
        log.warning("AI provider failure: %s", exc)
        raise HTTPException(503, "AI service is temporarily unavailable. Please try again.") from exc

    choices = data.get("choices") or []
    message = choices[0].get("message", {}).get("content") if choices else None
    if not message:
        raise HTTPException(502, "AI service returned no usable response.")
    return {"success": True, "data": {"message": message, "model": settings.ai_model}, "message": "AI response generated"}
